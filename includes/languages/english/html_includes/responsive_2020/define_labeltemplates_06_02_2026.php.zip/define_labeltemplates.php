<!--<title>Download Label Templates</title>-->

<!--<p><strong>We make the largest range of self-adhesive labels <em>in the world!</em> So it's pretty likely that we'll have what you need!</strong></p>-->
<!--<p>These templates are to help you set up your labels within graphics software. For help on printing labels through Microsoft Word visit our <a href="index.php?main_page=printlabels">How to print your own labels</a> page.</p>-->
<!--<p>Jump to section:</p>-->

<!--<h4>A4 Dies</h4>-->
<!--<ul>-->
<!--    <li><a href="index.php?main_page=labeltemplates#rec">Rectangle/Square</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#cir">Circle</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#oval">Oval</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#tri">Triangle</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#heart">Heart</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#star">Starburst</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#media">Media</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#other">Other Shapes</a></li>-->
<!--</ul>-->
<!--<h4>A3/SRA3 Dies</h4>-->
<!--<ul>-->
<!--    <li><a href="index.php?main_page=labeltemplates#a3rec">A3 Rectangles/Squares</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#a3other">A3 Other Shapes</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#sra3rec">SRA3 Rectangles/Squares</a></li>-->
<!--    <li><a href="index.php?main_page=labeltemplates#sra3other">SRA3 Other Shapes</a></li>-->
<!--</ul>-->
<!--<p>&nbsp;</p>-->
<!--<h2>A4 Die Templates</h2>-->
<!--<table class="trhover" cellspacing="0" cellpadding="2" border="0">-->
<!--<tbody>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="rec">Rectangle/Square</a></th>-->
<!--</tr>-->
<!--<tr><td>401 - Label Size 295.275mm x 210mm - 1 label per sheet</td><td><a href='/images/templates/CC401.pdf' target='_blank'>Download 401 Template</a></td></tr>-->
<!--<tr><td>412 - Label Size 295.2mm x 105mm - 2 labels per sheet</td><td><a href='/images/templates/CC412.pdf' target='_blank'>Download 412 Template</a></td></tr>-->
<!--<tr><td>427 - Label Size 295.2mm x 70mm - 3 labels per sheet</td><td><a href='/images/templates/CC427.pdf' target='_blank'>Download 427 Template</a></td></tr>-->
<!--<tr><td>402 - Label Size 287mm x 84mm - 2 labels per sheet</td><td><a href='/images/templates/CC402.pdf' target='_blank'>Download 402 Template</a></td></tr>-->
<!--<tr><td>436 - Label Size 284mm x 64mm - 3 labels per sheet</td><td><a href='/images/templates/CC436.pdf' target='_blank'>Download 436 Template</a></td></tr>-->
<!--<tr><td>450 - Label Size 284mm x 48mm - 4 labels per sheet</td><td><a href='/images/templates/CC450.pdf' target='_blank'>Download 450 Template</a></td></tr>-->
<!--<tr><td>407 - Label Size 283mm x 200mm - 1 label per sheet</td><td><a href='/images/templates/CC407.pdf' target='_blank'>Download 407 Template</a></td></tr>-->
<!--<tr><td>406 - Label Size 270mm x 30mm - 6 labels per sheet</td><td><a href='/images/templates/CC406.pdf' target='_blank'>Download 406 Template</a></td></tr>-->
<!--<tr><td>416 - Label Size 261mm x 38.5mm - 5 labels per sheet</td><td><a href='/images/templates/CC416.pdf' target='_blank'>Download 416 Template</a></td></tr>-->
<!--<tr><td>482 - Label Size 220mm x 42mm - 4 labels per sheet</td><td><a href='/images/templates/CC482.pdf' target='_blank'>Download 482 Template</a></td></tr>-->
<!--<tr><td>484 - Label Size 220mm x 23mm - 7 labels per sheet</td><td><a href='/images/templates/CC484.pdf' target='_blank'>Download 484 Template</a></td></tr>-->
<!--<tr><td>403 - Label Size 210mm x 147.6mm - 2 labels per sheet</td><td><a href='/images/templates/CC403.pdf' target='_blank'>Download 403 Template</a></td></tr>-->
<!--<tr><td>520 - Label Size 210mm x 98.4mm - 3 labels per sheet</td><td><a href='/images/templates/CC520.pdf' target='_blank'>Download 520 Template</a></td></tr>-->
<!--<tr><td>538 - Label Size 210mm x 73.8mm - 4 labels per sheet</td><td><a href='/images/templates/CC538.pdf' target='_blank'>Download 538 Template</a></td></tr>-->
<!--<tr><td>404 - Label Size 210mm x 40mm - 7 labels per sheet</td><td><a href='/images/templates/CC404.pdf' target='_blank'>Download 404 Template</a></td></tr>-->
<!--<tr><td>488 - Label Size 210mm x 20mm - 7 labels per sheet</td><td><a href='/images/templates/CC488.pdf' target='_blank'>Download 488 Template</a></td></tr>-->
<!--<tr><td>405 - Label Size 210mm x 12mm - 23 labels per sheet</td><td><a href='/images/templates/CC405.pdf' target='_blank'>Download 405 Template</a></td></tr>-->
<!--<tr><td>510 - Label Size 205mm x 40mm - 4 labels per sheet</td><td><a href='/images/templates/CC510.pdf' target='_blank'>Download 510 Template</a></td></tr>-->
<!--<tr><td>517 - Label Size 203mm x 38mm - 6 labels per sheet</td><td><a href='/images/templates/CC517.pdf' target='_blank'>Download 517 Template</a></td></tr>-->
<!--<tr><td>408 - Label Size 200mm x 140mm - 2 labels per sheet</td><td><a href='/images/templates/CC408.pdf' target='_blank'>Download 408 Template</a></td></tr>-->
<!--<tr><td>409 - Label Size 200mm x 94mm - 3 labels per sheet</td><td><a href='/images/templates/CC409.pdf' target='_blank'>Download 409 Template</a></td></tr>-->
<!--<tr><td>410 - Label Size 200mm x 69mm - 4 labels per sheet</td><td><a href='/images/templates/CC410.pdf' target='_blank'>Download 410 Template</a></td></tr>-->
<!--<tr><td>411 - Label Size 200mm x 54mm - 5 labels per sheet</td><td><a href='/images/templates/CC411.pdf' target='_blank'>Download 411 Template</a></td></tr>-->
<!--<tr><td>513 - Label Size 200mm x 30mm - 9 labels per sheet</td><td><a href='/images/templates/CC513.pdf' target='_blank'>Download 513 Template</a></td></tr>-->
<!--<tr><td>532 - Label Size 199.6mm x 143.5mm - 2 labels per sheet</td><td><a href='/images/templates/CC532.pdf' target='_blank'>Download 532 Template</a></td></tr>-->
<!--<tr><td>519 - Label Size 195mm x 75mm - 3 labels per sheet</td><td><a href='/images/templates/CC519.pdf' target='_blank'>Download 519 Template</a></td></tr>-->
<!--<tr><td>521 - Label Size 177mm x 46mm - 5 labels per sheet</td><td><a href='/images/templates/CC521.pdf' target='_blank'>Download 521 Template</a></td></tr>-->
<!--<tr><td>555 - Label Size 174mm x 63mm - 4 labels per sheet</td><td><a href='/images/templates/CC555.pdf' target='_blank'>Download 555 Template</a></td></tr>-->
<!--<tr><td>596 - Label Size 170mm x 90mm - 3 labels per sheet</td><td><a href='/images/templates/CC596.pdf' target='_blank'>Download 596 Template</a></td></tr>-->
<!--<tr><td>597 - Label Size 165mm x 85mm - 3 labels per sheet</td><td><a href='/images/templates/CC597.pdf' target='_blank'>Download 597 Template</a></td></tr>-->
<!--<tr><td>598 - Label Size 165mm x 53mm - 4 labels per sheet</td><td><a href='/images/templates/CC598.pdf' target='_blank'>Download 598 Template</a></td></tr>-->
<!--<tr><td>599 - Label Size 155mm x 40mm - 6 labels per sheet</td><td><a href='/images/templates/CC599.pdf' target='_blank'>Download 599 Template</a></td></tr>-->
<!--<tr><td>600 - Label Size 151mm x 43mm - 5 labels per sheet</td><td><a href='/images/templates/CC600.pdf' target='_blank'>Download 600 Template</a></td></tr>-->
<!--<tr><td>601 - Label Size 150mm x 90mm - 3 labels per sheet</td><td><a href='/images/templates/CC601.pdf' target='_blank'>Download 601 Template</a></td></tr>-->
<!--<tr><td>413 - Label Size 147.6mm x 105mm - 4 labels per sheet</td><td><a href='/images/templates/CC413.pdf' target='_blank'>Download 413 Template</a></td></tr>-->
<!--<tr><td>464 - Label Size 145mm x 19mm - 14 labels per sheet</td><td><a href='/images/templates/CC464.pdf' target='_blank'>Download 464 Template</a></td></tr>-->
<!--<tr><td>531 - Label Size 145mm x 16.9mm - 16 labels per sheet</td><td><a href='/images/templates/CC531.pdf' target='_blank'>Download 531 Template</a></td></tr>-->
<!--<tr><td>417 - Label Size 140mm x 97mm - 4 labels per sheet</td><td><a href='/images/templates/CC417.pdf' target='_blank'>Download 417 Template</a></td></tr>-->
<!--<tr><td>602 - Label Size 140mm x 35mm - 10 labels per sheet</td><td><a href='/images/templates/CC602.pdf' target='_blank'>Download 602 Template</a></td></tr>-->
<!--<tr><td>523 - Label Size 139mm x 99.1mm - 4 labels per sheet</td><td><a href='/images/templates/CC523.pdf' target='_blank'>Download 523 Template</a></td></tr>-->
<!--<tr><td>437 - Label Size 138mm x 64mm - 6 labels per sheet</td><td><a href='/images/templates/CC437.pdf' target='_blank'>Download 437 Template</a></td></tr>-->
<!--<tr><td>447 - Label Size 138mm x 50mm - 8 labels per sheet</td><td><a href='/images/templates/CC447.pdf' target='_blank'>Download 447 Template</a></td></tr>-->
<!--<tr><td>603 - Label Size 135mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates/CC603.pdf' target='_blank'>Download 603 Template</a></td></tr>-->
<!--<tr><td>512 - Label Size 135mm x 55mm - 6 labels per sheet</td><td><a href='/images/templates/CC512.pdf' target='_blank'>Download 512 Template</a></td></tr>-->
<!--<tr><td>591 - Label Size 135mm x 45mm - 8 labels per sheet</td><td><a href='/images/templates/CC591.pdf' target='_blank'>Download 591 Template</a></td></tr>-->
<!--<tr><td>604 - Label Size 128mm x 44mm - 8 labels per sheet</td><td><a href='/images/templates/CC604.pdf' target='_blank'>Download 604 Template</a></td></tr>-->
<!--<tr><td>575 - Label Size 125mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates/CC575.pdf' target='_blank'>Download 575 Template</a></td></tr>-->
<!--<tr><td>605 - Label Size 120mm x 38mm - 7 labels per sheet</td><td><a href='/images/templates/CC605.pdf' target='_blank'>Download 605 Template</a></td></tr>-->
<!--<tr><td>606 - Label Size 119mm x 55mm - 6 labels per sheet</td><td><a href='/images/templates/CC606.pdf' target='_blank'>Download 606 Template</a></td></tr>-->
<!--<tr><td>607 - Label Size 117.5mm x 87mm - 4 labels per sheet</td><td><a href='/images/templates/CC607.pdf' target='_blank'>Download 607 Template</a></td></tr>-->
<!--<tr><td>608 - Label Size 112.5mm x 45mm - 8 labels per sheet</td><td><a href='/images/templates/CC608.pdf' target='_blank'>Download 608 Template</a></td></tr>-->
<!--<tr><td>609 - Label Size 110mm x 90mm - 4 labels per sheet</td><td><a href='/images/templates/CC609.pdf' target='_blank'>Download 609 Template</a></td></tr>-->
<!--<tr><td>501 - Label Size 105mm x 94.5mm - 6 labels per sheet</td><td><a href='/images/templates/CC501.pdf' target='_blank'>Download 501 Template</a></td></tr>-->
<!--<tr><td>414 - Label Size 105mm x 73.8mm - 8 labels per sheet</td><td><a href='/images/templates/CC414.pdf' target='_blank'>Download 414 Template</a></td></tr>-->
<!--<tr><td>522 - Label Size 105mm x 49.2mm - 12 labels per sheet</td><td><a href='/images/templates/CC522.pdf' target='_blank'>Download 522 Template</a></td></tr>-->
<!--<tr><td>610 - Label Size 105mm x 40mm - 8 labels per sheet</td><td><a href='/images/templates/CC610.pdf' target='_blank'>Download 610 Template</a></td></tr>-->
<!--<tr><td>415 - Label Size 105mm x 36.9mm - 16 labels per sheet</td><td><a href='/images/templates/CC415.pdf' target='_blank'>Download 415 Template</a></td></tr>-->
<!--<tr><td>611 - Label Size 105.25mm x 35mm - 10 labels per sheet</td><td><a href='/images/templates/CC611.pdf' target='_blank'>Download 611 Template</a></td></tr>-->
<!--<tr><td>581 - Label Size 105mm x 25.4mm - 22 labels per sheet</td><td><a href='/images/templates/CC581.pdf' target='_blank'>Download 581 Template</a></td></tr>-->
<!--<tr><td>588 - Label Size 100mm x 10mm - 24 labels per sheet</td><td><a href='/images/templates/CC588.pdf' target='_blank'>Download 588 Template</a></td></tr>-->
<!--<tr><td>524 - Label Size 99.1mm x 93.1mm - 6 labels per sheet</td><td><a href='/images/templates/CC524.pdf' target='_blank'>Download 524 Template</a></td></tr>-->
<!--<tr><td>525 - Label Size 99.1mm x 67.7mm - 8 labels per sheet</td><td><a href='/images/templates/CC525.pdf' target='_blank'>Download 525 Template</a></td></tr>-->
<!--<tr><td>533 - Label Size 99mm x 57mm - 10 labels per sheet</td><td><a href='/images/templates/CC533.pdf' target='_blank'>Download 533 Template</a></td></tr>-->
<!--<tr><td>526 - Label Size 99.1mm x 38.1mm - 14 labels per sheet</td><td><a href='/images/templates/CC526.pdf' target='_blank'>Download 526 Template</a></td></tr>-->
<!--<tr><td>527 - Label Size 99.1mm x 34mm - 16 labels per sheet</td><td><a href='/images/templates/CC527.pdf' target='_blank'>Download 527 Template</a></td></tr>-->
<!--<tr><td>580 - Label Size 98mm x 25.4mm - 20 labels per sheet</td><td><a href='/images/templates/CC580.pdf' target='_blank'>Download 580 Template</a></td></tr>-->
<!--<tr><td>418 - Label Size 97mm x 89mm - 6 labels per sheet</td><td><a href='/images/templates/CC418.pdf' target='_blank'>Download 418 Template</a></td></tr>-->
<!--<tr><td>539 - Label Size 97mm x 68mm - 8 labels per sheet</td><td><a href='/images/templates/CC539.pdf' target='_blank'>Download 539 Template</a></td></tr>-->
<!--<tr><td>559 - Label Size 97mm x 66mm - 8 labels per sheet</td><td><a href='/images/templates/CC559.pdf' target='_blank'>Download 559 Template</a></td></tr>-->
<!--<tr><td>419 - Label Size 97mm x 56.5mm - 10 labels per sheet</td><td><a href='/images/templates/CC419.pdf' target='_blank'>Download 419 Template</a></td></tr>-->
<!--<tr><td>540 - Label Size 97mm x 50mm - 10 labels per sheet</td><td><a href='/images/templates/CC540.pdf' target='_blank'>Download 540 Template</a></td></tr>-->
<!--<tr><td>420 - Label Size 97mm x 47.5mm - 12 labels per sheet</td><td><a href='/images/templates/CC420.pdf' target='_blank'>Download 420 Template</a></td></tr>-->
<!--<tr><td>421 - Label Size 97mm x 40mm - 14 labels per sheet</td><td><a href='/images/templates/CC421.pdf' target='_blank'>Download 421 Template</a></td></tr>-->
<!--<tr><td>422 - Label Size 97mm x 34mm - 16 labels per sheet</td><td><a href='/images/templates/CC422.pdf' target='_blank'>Download 422 Template</a></td></tr>-->
<!--<tr><td>541 - Label Size 97mm x 26mm - 20 labels per sheet</td><td><a href='/images/templates/CC541.pdf' target='_blank'>Download 541 Template</a></td></tr>-->
<!--<tr><td>423 - Label Size 97mm x 20mm - 28 labels per sheet</td><td><a href='/images/templates/CC423.pdf' target='_blank'>Download 423 Template</a></td></tr>-->
<!--<tr><td>424 - Label Size 97mm x 15mm - 36 labels per sheet</td><td><a href='/images/templates/CC424.pdf' target='_blank'>Download 424 Template</a></td></tr>-->
<!--<tr><td>425 - Label Size 95mm x 93mm - 6 labels per sheet</td><td><a href='/images/templates/CC425.pdf' target='_blank'>Download 425 Template</a></td></tr>-->
<!--<tr><td>612 - Label Size 95mm x 65mm - 8 labels per sheet</td><td><a href='/images/templates/CC612.pdf' target='_blank'>Download 612 Template</a></td></tr>-->
<!--<tr><td>613 - Label Size 94mm x 49mm - 10 labels per sheet</td><td><a href='/images/templates/CC613.pdf' target='_blank'>Download 613 Template</a></td></tr>-->
<!--<tr><td>438 - Label Size 93mm x 64mm - 9 labels per sheet</td><td><a href='/images/templates/CC438.pdf' target='_blank'>Download 438 Template</a></td></tr>-->
<!--<tr><td>614 - Label Size 93mm x 36mm - 14 labels per sheet</td><td><a href='/images/templates/CC614.pdf' target='_blank'>Download 614 Template</a></td></tr>-->
<!--<tr><td>615 - Label Size 92.5mm x 47mm - 8 labels per sheet</td><td><a href='/images/templates/CC615.pdf' target='_blank'>Download 615 Template</a></td></tr>-->
<!--<tr><td>446 - Label Size 90mm x 55mm - 9 labels per sheet</td><td><a href='/images/templates/CC446.pdf' target='_blank'>Download 446 Template</a></td></tr>-->
<!--<tr><td>514 - Label Size 90mm x 50mm - 10 labels per sheet</td><td><a href='/images/templates/CC514.pdf' target='_blank'>Download 514 Template</a></td></tr>-->
<!--<tr><td>616 - Label Size 90mm x 50mm - 10 labels per sheet</td><td><a href='/images/templates/CC616.pdf' target='_blank'>Download 616 Template</a></td></tr>-->
<!--<tr><td>617 - Label Size 90mm x 45mm - 10 labels per sheet</td><td><a href='/images/templates/CC617.pdf' target='_blank'>Download 617 Template</a></td></tr>-->
<!--<tr><td>542 - Label Size 90mm x 35mm - 14 labels per sheet</td><td><a href='/images/templates/CC542.pdf' target='_blank'>Download 542 Template</a></td></tr>-->
<!--<tr><td>618 - Label Size 89mm x 25mm - 21 labels per sheet</td><td><a href='/images/templates/CC618.pdf' target='_blank'>Download 618 Template</a></td></tr>-->
<!--<tr><td>590 - Label Size 88mm x 88mm - 6 labels per sheet</td><td><a href='/images/templates/CC590.pdf' target='_blank'>Download 590 Template</a></td></tr>-->
<!--<tr><td>619 - Label Size 88mm x 18mm - 30 labels per sheet</td><td><a href='/images/templates/CC619.pdf' target='_blank'>Download 619 Template</a></td></tr>-->
<!--<tr><td>620 - Label Size 87.53mm x 16.6mm - 26 labels per sheet</td><td><a href='/images/templates/CC620.pdf' target='_blank'>Download 620 Template</a></td></tr>-->
<!--<tr><td>621 - Label Size 86mm x 52.9mm - 8 labels per sheet</td><td><a href='/images/templates/CC621.pdf' target='_blank'>Download 621 Template</a></td></tr>-->
<!--<tr><td>622 - Label Size 85mm x 85mm - 6 labels per sheet</td><td><a href='/images/templates/CC622.pdf' target='_blank'>Download 622 Template</a></td></tr>-->
<!--<tr><td>623 - Label Size 85mm x 70mm - 6 labels per sheet</td><td><a href='/images/templates/CC623.pdf' target='_blank'>Download 623 Template</a></td></tr>-->
<!--<tr><td>578 - Label Size 84mm x 45mm - 12 labels per sheet</td><td><a href='/images/templates/CC578.pdf' target='_blank'>Download 578 Template</a></td></tr>-->
<!--<tr><td>624 - Label Size 83mm x 17mm - 30 labels per sheet</td><td><a href='/images/templates/CC624.pdf' target='_blank'>Download 624 Template</a></td></tr>-->
<!--<tr><td>625 - Label Size 82mm x 27mm - 18 labels per sheet</td><td><a href='/images/templates/CC625.pdf' target='_blank'>Download 625 Template</a></td></tr>-->
<!--<tr><td>626 - Label Size 81mm x 60mm - 9 labels per sheet</td><td><a href='/images/templates/CC626.pdf' target='_blank'>Download 626 Template</a></td></tr>-->
<!--<tr><td>627 - Label Size 81mm x 55.827mm - 8 labels per sheet</td><td><a href='/images/templates/CC627.pdf' target='_blank'>Download 627 Template</a></td></tr>-->
<!--<tr><td>628 - Label Size 81mm x 9mm - 45 labels per sheet</td><td><a href='/images/templates/CC628.pdf' target='_blank'>Download 628 Template</a></td></tr>-->
<!--<tr><td>574 - Label Size 80mm x 80mm - 6 labels per sheet</td><td><a href='/images/templates/CC574.pdf' target='_blank'>Download 574 Template</a></td></tr>-->
<!--<tr><td>577 - Label Size 80mm x 65mm - 8 labels per sheet</td><td><a href='/images/templates/CC577.pdf' target='_blank'>Download 577 Template</a></td></tr>-->
<!--<tr><td>629 - Label Size 80.081mm x 49.742mm - 10 labels per sheet</td><td><a href='/images/templates/CC629.pdf' target='_blank'>Download 629 Template</a></td></tr>-->
<!--<tr><td>630 - Label Size 80mm x 30mm - 18 labels per sheet</td><td><a href='/images/templates/CC630.pdf' target='_blank'>Download 630 Template</a></td></tr>-->
<!--<tr><td>631 - Label Size 80mm x 20mm - 22 labels per sheet</td><td><a href='/images/templates/CC631.pdf' target='_blank'>Download 631 Template</a></td></tr>-->
<!--<tr><td>632 - Label Size 80mm x 10mm - 40 labels per sheet</td><td><a href='/images/templates/CC632.pdf' target='_blank'>Download 632 Template</a></td></tr>-->
<!--<tr><td>633 - Label Size 78mm x 28mm - 16 labels per sheet</td><td><a href='/images/templates/CC633.pdf' target='_blank'>Download 633 Template</a></td></tr>-->
<!--<tr><td>426 - Label Size 77mm x 46.5mm - 12 labels per sheet</td><td><a href='/images/templates/CC426.pdf' target='_blank'>Download 426 Template</a></td></tr>-->
<!--<tr><td>586 - Label Size 75mm x 60mm - 8 labels per sheet</td><td><a href='/images/templates/CC586.pdf' target='_blank'>Download 586 Template</a></td></tr>-->
<!--<tr><td>543 - Label Size 75mm x 51mm - 10 labels per sheet</td><td><a href='/images/templates/CC543.pdf' target='_blank'>Download 543 Template</a></td></tr>-->
<!--<tr><td>634 - Label Size 75mm x 40mm - 12 labels per sheet</td><td><a href='/images/templates/CC634.pdf' target='_blank'>Download 634 Template</a></td></tr>-->
<!--<tr><td>545 - Label Size 75mm x 34mm - 15 labels per sheet</td><td><a href='/images/templates/CC545.pdf' target='_blank'>Download 545 Template</a></td></tr>-->
<!--<tr><td>635 - Label Size 75mm x 32mm - 15 labels per sheet</td><td><a href='/images/templates/CC635.pdf' target='_blank'>Download 635 Template</a></td></tr>-->
<!--<tr><td>550 - Label Size 73mm x 23mm - 24 labels per sheet</td><td><a href='/images/templates/CC550.pdf' target='_blank'>Download 550 Template</a></td></tr>-->
<!--<tr><td>534 - Label Size 72mm x 63.5mm - 12 labels per sheet</td><td><a href='/images/templates/CC534.pdf' target='_blank'>Download 534 Template</a></td></tr>-->
<!--<tr><td>636 - Label Size 72mm x 31mm - 14 labels per sheet</td><td><a href='/images/templates/CC636.pdf' target='_blank'>Download 636 Template</a></td></tr>-->
<!--<tr><td>428 - Label Size 71mm x 70mm - 8 labels per sheet</td><td><a href='/images/templates/CC428.pdf' target='_blank'>Download 428 Template</a></td></tr>-->
<!--<tr><td>441 - Label Size 71mm x 63.5mm - 12 labels per sheet</td><td><a href='/images/templates/CC441.pdf' target='_blank'>Download 441 Template</a></td></tr>-->
<!--<tr><td>451 - Label Size 71mm x 48mm - 16 labels per sheet</td><td><a href='/images/templates/CC451.pdf' target='_blank'>Download 451 Template</a></td></tr>-->
<!--<tr><td>429 - Label Size 70mm x 70mm - 12 labels per sheet</td><td><a href='/images/templates/CC429.pdf' target='_blank'>Download 429 Template</a></td></tr>-->
<!--<tr><td>430 - Label Size 70mm x 47mm - 18 labels per sheet</td><td><a href='/images/templates/CC430.pdf' target='_blank'>Download 430 Template</a></td></tr>-->
<!--<tr><td>637 - Label Size 70mm x 40mm - 12 labels per sheet</td><td><a href='/images/templates/CC637.pdf' target='_blank'>Download 637 Template</a></td></tr>-->
<!--<tr><td>431 - Label Size 70mm x 35mm - 24 labels per sheet</td><td><a href='/images/templates/CC431.pdf' target='_blank'>Download 431 Template</a></td></tr>-->
<!--<tr><td>432 - Label Size 70mm x 25.4mm - 33 labels per sheet</td><td><a href='/images/templates/CC432.pdf' target='_blank'>Download 432 Template</a></td></tr>-->
<!--<tr><td>433 - Label Size 70mm x 20mm - 42 labels per sheet</td><td><a href='/images/templates/CC433.pdf' target='_blank'>Download 433 Template</a></td></tr>-->
<!--<tr><td>638 - Label Size 70mm x 18mm - 24 labels per sheet</td><td><a href='/images/templates/CC638.pdf' target='_blank'>Download 638 Template</a></td></tr>-->
<!--<tr><td>434 - Label Size 70mm x 12mm - 69 labels per sheet</td><td><a href='/images/templates/CC434.pdf' target='_blank'>Download 434 Template</a></td></tr>-->
<!--<tr><td>439 - Label Size 65mm x 65mm - 12 labels per sheet</td><td><a href='/images/templates/CC439.pdf' target='_blank'>Download 439 Template</a></td></tr>-->
<!--<tr><td>440 - Label Size 65mm x 40mm - 18 labels per sheet</td><td><a href='/images/templates/CC440.pdf' target='_blank'>Download 440 Template</a></td></tr>-->
<!--<tr><td>639 - Label Size 65mm x 7mm - 40 labels per sheet</td><td><a href='/images/templates/CC639.pdf' target='_blank'>Download 639 Template</a></td></tr>-->
<!--<tr><td>435 - Label Size 64mm x 54mm - 15 labels per sheet</td><td><a href='/images/templates/CC435.pdf' target='_blank'>Download 435 Template</a></td></tr>-->
<!--<tr><td>536 - Label Size 64mm x 33.9mm - 24 labels per sheet</td><td><a href='/images/templates/CC536.pdf' target='_blank'>Download 536 Template</a></td></tr>-->
<!--<tr><td>582 - Label Size 64mm x 25.4mm - 30 labels per sheet</td><td><a href='/images/templates/CC582.pdf' target='_blank'>Download 582 Template</a></td></tr>-->
<!--<tr><td>442 - Label Size 63.5mm x 46.5mm - 18 labels per sheet</td><td><a href='/images/templates/CC442.pdf' target='_blank'>Download 442 Template</a></td></tr>-->
<!--<tr><td>535 - Label Size 63.5mm x 46.6mm - 18 labels per sheet</td><td><a href='/images/templates/CC535.pdf' target='_blank'>Download 535 Template</a></td></tr>-->
<!--<tr><td>528 - Label Size 63.5mm x 38.1mm - 21 labels per sheet</td><td><a href='/images/templates/CC528.pdf' target='_blank'>Download 528 Template</a></td></tr>-->
<!--<tr><td>443 - Label Size 63.5mm x 34mm - 24 labels per sheet</td><td><a href='/images/templates/CC443.pdf' target='_blank'>Download 443 Template</a></td></tr>-->
<!--<tr><td>444 - Label Size 63.5mm x 24mm - 33 labels per sheet</td><td><a href='/images/templates/CC444.pdf' target='_blank'>Download 444 Template</a></td></tr>-->
<!--<tr><td>579 - Label Size 63.5mm x 23mm - 36 labels per sheet</td><td><a href='/images/templates/CC579.pdf' target='_blank'>Download 579 Template</a></td></tr>-->
<!--<tr><td>552 - Label Size 63mm x 18mm - 40 labels per sheet</td><td><a href='/images/templates/CC552.pdf' target='_blank'>Download 552 Template</a></td></tr>-->
<!--<tr><td>445 - Label Size 60mm x 50mm - 15 labels per sheet</td><td><a href='/images/templates/CC445.pdf' target='_blank'>Download 445 Template</a></td></tr>-->
<!--<tr><td>573 - Label Size 60mm x 32mm - 24 labels per sheet</td><td><a href='/images/templates/CC573.pdf' target='_blank'>Download 573 Template</a></td></tr>-->
<!--<tr><td>640 - Label Size 60mm x 32mm - 24 labels per sheet</td><td><a href='/images/templates/CC640.pdf' target='_blank'>Download 640 Template</a></td></tr>-->
<!--<tr><td>584 - Label Size 60mm x 20mm - 36 labels per sheet</td><td><a href='/images/templates/CC584.pdf' target='_blank'>Download 584 Template</a></td></tr>-->
<!--<tr><td>641 - Label Size 60mm x 11mm - 51 labels per sheet</td><td><a href='/images/templates/CC641.pdf' target='_blank'>Download 641 Template</a></td></tr>-->
<!--<tr><td>642 - Label Size 56mm x 20mm - 36 labels per sheet</td><td><a href='/images/templates/CC642.pdf' target='_blank'>Download 642 Template</a></td></tr>-->
<!--<tr><td>643 - Label Size 55mm x 40mm - 18 labels per sheet</td><td><a href='/images/templates/CC643.pdf' target='_blank'>Download 643 Template</a></td></tr>-->
<!--<tr><td>644 - Label Size 55mm x 10mm - 81 labels per sheet</td><td><a href='/images/templates/CC644.pdf' target='_blank'>Download 644 Template</a></td></tr>-->
<!--<tr><td>585 - Label Size 52mm x 42mm - 20 labels per sheet</td><td><a href='/images/templates/CC585.pdf' target='_blank'>Download 585 Template</a></td></tr>-->
<!--<tr><td>463 - Label Size 52mm x 16mm - 60 labels per sheet</td><td><a href='/images/templates/CC463.pdf' target='_blank'>Download 463 Template</a></td></tr>-->
<!--<tr><td>645 - Label Size 51.5mm x 46mm - 20 labels per sheet</td><td><a href='/images/templates/CC645.pdf' target='_blank'>Download 645 Template</a></td></tr>-->
<!--<tr><td>546 - Label Size 51mm x 34mm - 25 labels per sheet</td><td><a href='/images/templates/CC546.pdf' target='_blank'>Download 546 Template</a></td></tr>-->
<!--<tr><td>549 - Label Size 51mm x 24mm - 35 labels per sheet</td><td><a href='/images/templates/CC549.pdf' target='_blank'>Download 549 Template</a></td></tr>-->
<!--<tr><td>448 - Label Size 50mm x 50mm - 20 labels per sheet</td><td><a href='/images/templates/CC448.pdf' target='_blank'>Download 448 Template</a></td></tr>-->
<!--<tr><td>544 - Label Size 50mm x 50mm - 15 labels per sheet</td><td><a href='/images/templates/CC544.pdf' target='_blank'>Download 544 Template</a></td></tr>-->
<!--<tr><td>452 - Label Size 48mm x 38mm - 28 labels per sheet</td><td><a href='/images/templates/CC452.pdf' target='_blank'>Download 452 Template</a></td></tr>-->
<!--<tr><td>449 - Label Size 48.5mm x 25.4mm - 40 labels per sheet</td><td><a href='/images/templates/CC449.pdf' target='_blank'>Download 449 Template</a></td></tr>-->
<!--<tr><td>646 - Label Size 48mm x 23.5mm - 30 labels per sheet</td><td><a href='/images/templates/CC646.pdf' target='_blank'>Download 646 Template</a></td></tr>-->
<!--<tr><td>453 - Label Size 48mm x 20mm - 56 labels per sheet</td><td><a href='/images/templates/CC453.pdf' target='_blank'>Download 453 Template</a></td></tr>-->
<!--<tr><td>454 - Label Size 48mm x 12mm - 92 labels per sheet</td><td><a href='/images/templates/CC454.pdf' target='_blank'>Download 454 Template</a></td></tr>-->
<!--<tr><td>647 - Label Size 47mm x 28.36mm - 36 labels per sheet</td><td><a href='/images/templates/CC647.pdf' target='_blank'>Download 647 Template</a></td></tr>-->
<!--<tr><td>558 - Label Size 46mm x 11.1mm - 84 labels per sheet</td><td><a href='/images/templates/CC558.pdf' target='_blank'>Download 558 Template</a></td></tr>-->
<!--<tr><td>648 - Label Size 45mm x 45mm - 24 labels per sheet</td><td><a href='/images/templates/CC648.pdf' target='_blank'>Download 648 Template</a></td></tr>-->
<!--<tr><td>649 - Label Size 45mm x 31mm - 36 labels per sheet</td><td><a href='/images/templates/CC649.pdf' target='_blank'>Download 649 Template</a></td></tr>-->
<!--<tr><td>650 - Label Size 45mm x 25mm - 44 labels per sheet</td><td><a href='/images/templates/CC650.pdf' target='_blank'>Download 650 Template</a></td></tr>-->
<!--<tr><td>652 - Label Size 43mm x 21mm - 44 labels per sheet</td><td><a href='/images/templates/CC652.pdf' target='_blank'>Download 652 Template</a></td></tr>-->
<!--<tr><td>924 - Label Size 43mm x 10mm - 27 labels per sheet</td><td><a href='/images/templates/CC924.pdf' target='_blank'>Download 924 Template</a></td></tr>-->
<!--<tr><td>653 - Label Size 42mm x 18mm - 56 labels per sheet</td><td><a href='/images/templates/CC653.pdf' target='_blank'>Download 653 Template</a></td></tr>-->
<!--<tr><td>654 - Label Size 41mm x 25mm - 48 labels per sheet</td><td><a href='/images/templates/CC654.pdf' target='_blank'>Download 654 Template</a></td></tr>-->
<!--<tr><td>511 - Label Size 40mm x 15mm - 90 labels per sheet</td><td><a href='/images/templates/CC511.pdf' target='_blank'>Download 511 Template</a></td></tr>-->
<!--<tr><td>455 - Label Size 38mm x 38mm - 35 labels per sheet</td><td><a href='/images/templates/CC455.pdf' target='_blank'>Download 455 Template</a></td></tr>-->
<!--<tr><td>456 - Label Size 38mm x 25.4mm - 50 labels per sheet</td><td><a href='/images/templates/CC456.pdf' target='_blank'>Download 456 Template</a></td></tr>-->
<!--<tr><td>655 - Label Size 38mm x 24mm - 40 labels per sheet</td><td><a href='/images/templates/CC655.pdf' target='_blank'>Download 655 Template</a></td></tr>-->
<!--<tr><td>529 - Label Size 38.1mm x 21.2mm - 65 labels per sheet</td><td><a href='/images/templates/CC529.pdf' target='_blank'>Download 529 Template</a></td></tr>-->
<!--<tr><td>457 - Label Size 35mm x 30mm - 54 labels per sheet</td><td><a href='/images/templates/CC457.pdf' target='_blank'>Download 457 Template</a></td></tr>-->
<!--<tr><td>458 - Label Size 35mm x 6mm - 155 labels per sheet</td><td><a href='/images/templates/CC458.pdf' target='_blank'>Download 458 Template</a></td></tr>-->
<!--<tr><td>551 - Label Size 34mm x 21mm - 63 labels per sheet</td><td><a href='/images/templates/CC551.pdf' target='_blank'>Download 551 Template</a></td></tr>-->
<!--<tr><td>562 - Label Size 33mm x 33mm - 40 labels per sheet</td><td><a href='/images/templates/CC562.pdf' target='_blank'>Download 562 Template</a></td></tr>-->
<!--<tr><td>547 - Label Size 33.5mm x 15mm - 80 labels per sheet</td><td><a href='/images/templates/CC547.pdf' target='_blank'>Download 547 Template</a></td></tr>-->
<!--<tr><td>515 - Label Size 32mm x 24mm - 72 labels per sheet</td><td><a href='/images/templates/CC515.pdf' target='_blank'>Download 515 Template</a></td></tr>-->
<!--<tr><td>656 - Label Size 32mm x 24mm - 64 labels per sheet</td><td><a href='/images/templates/CC656.pdf' target='_blank'>Download 656 Template</a></td></tr>-->
<!--<tr><td>459 - Label Size 30mm x 30mm - 48 labels per sheet</td><td><a href='/images/templates/CC459.pdf' target='_blank'>Download 459 Template</a></td></tr>-->
<!--<tr><td>507 - Label Size 30mm x 16mm - 96 labels per sheet</td><td><a href='/images/templates/CC507.pdf' target='_blank'>Download 507 Template</a></td></tr>-->
<!--<tr><td>548 - Label Size 30mm x 10mm - 168 labels per sheet</td><td><a href='/images/templates/CC548.pdf' target='_blank'>Download 548 Template</a></td></tr>-->
<!--<tr><td>576 - Label Size 25mm x 25mm - 70 labels per sheet</td><td><a href='/images/templates/CC576.pdf' target='_blank'>Download 576 Template</a></td></tr>-->
<!--<tr><td>460 - Label Size 25mm x 15mm - 126 labels per sheet</td><td><a href='/images/templates/CC460.pdf' target='_blank'>Download 460 Template</a></td></tr>-->
<!--<tr><td>516 - Label Size 25mm x 12mm - 120 labels per sheet</td><td><a href='/images/templates/CC516.pdf' target='_blank'>Download 516 Template</a></td></tr>-->
<!--<tr><td>657 - Label Size 25mm x 8mm - 114 labels per sheet</td><td><a href='/images/templates/CC657.pdf' target='_blank'>Download 657 Template</a></td></tr>-->
<!--<tr><td>658 - Label Size 24mm x 19mm - 90 labels per sheet</td><td><a href='/images/templates/CC658.pdf' target='_blank'>Download 658 Template</a></td></tr>-->
<!--<tr><td>461 - Label Size 20mm x 20mm - 126 labels per sheet</td><td><a href='/images/templates/CC461.pdf' target='_blank'>Download 461 Template</a></td></tr>-->
<!--<tr><td>462 - Label Size 20mm x 10mm - 252 labels per sheet</td><td><a href='/images/templates/CC462.pdf' target='_blank'>Download 462 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="cir">Circle</a></th>-->
<!--</tr>-->
<!--<tr><td>474 - Label Size 200mm dia - 1 label per sheet</td><td><a href='/images/templates/CC474.pdf' target='_blank'>Download 474 Template</a></td></tr>-->
<!--<tr><td>661 - Label Size 150mm dia - 1 label per sheet</td><td><a href='/images/templates/CC661.pdf' target='_blank'>Download 661 Template</a></td></tr>-->
<!--<tr><td>473 - Label Size 140mm dia - 2 labels per sheet</td><td><a href='/images/templates/CC473.pdf' target='_blank'>Download 473 Template</a></td></tr>-->
<!--<tr><td>472 - Label Size 112mm dia - 3 labels per sheet</td><td><a href='/images/templates/CC472.pdf' target='_blank'>Download 472 Template</a></td></tr>-->
<!--<tr><td>565 - Label Size 112mm dia - 3 labels per sheet</td><td><a href='/images/templates/CC565.pdf' target='_blank'>Download 565 Template</a></td></tr>-->
<!--<tr><td>592 - Label Size 100mm dia - 4 labels per sheet</td><td><a href='/images/templates/CC592.pdf' target='_blank'>Download 592 Template</a></td></tr>-->
<!--<tr><td>471 - Label Size 90mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC471.pdf' target='_blank'>Download 471 Template</a></td></tr>-->
<!--<tr><td>662 - Label Size 85mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC662.pdf' target='_blank'>Download 662 Template</a></td></tr>-->
<!--<tr><td>593 - Label Size 80mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC593.pdf' target='_blank'>Download 593 Template</a></td></tr>-->
<!--<tr><td>663 - Label Size 75mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC663.pdf' target='_blank'>Download 663 Template</a></td></tr>-->
<!--<tr><td>594 - Label Size 71mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC594.pdf' target='_blank'>Download 594 Template</a></td></tr>-->
<!--<tr><td>470 - Label Size 65mm dia - 12 labels per sheet</td><td><a href='/images/templates/CC470.pdf' target='_blank'>Download 470 Template</a></td></tr>-->
<!--<tr><td>664 - Label Size 60mm dia - 12 labels per sheet</td><td><a href='/images/templates/CC664.pdf' target='_blank'>Download 664 Template</a></td></tr>-->
<!--<tr><td>665 - Label Size 57mm dia - 12 labels per sheet</td><td><a href='/images/templates/CC665.pdf' target='_blank'>Download 665 Template</a></td></tr>-->
<!--<tr><td>572 - Label Size 53mm dia - 15 labels per sheet</td><td><a href='/images/templates/CC572.pdf' target='_blank'>Download 572 Template</a></td></tr>-->
<!--<tr><td>469 - Label Size 50mm dia - 20 labels per sheet</td><td><a href='/images/templates/CC469.pdf' target='_blank'>Download 469 Template</a></td></tr>-->
<!--<tr><td>564 - Label Size 50mm dia - 15 labels per sheet</td><td><a href='/images/templates/CC564.pdf' target='_blank'>Download 564 Template</a></td></tr>-->
<!--<tr><td>553 - Label Size 45mm dia - 24 labels per sheet</td><td><a href='/images/templates/CC553.pdf' target='_blank'>Download 553 Template</a></td></tr>-->
<!--<tr><td>666 - Label Size 43mm dia - 24 labels per sheet</td><td><a href='/images/templates/CC666.pdf' target='_blank'>Download 666 Template</a></td></tr>-->
<!--<tr><td>595 - Label Size 41mm dia - 24 labels per sheet</td><td><a href='/images/templates/CC595.pdf' target='_blank'>Download 595 Template</a></td></tr>-->
<!--<tr><td>667 - Label Size 38mm dia - 30 labels per sheet</td><td><a href='/images/templates/CC667.pdf' target='_blank'>Download 667 Template</a></td></tr>-->
<!--<tr><td>668 - Label Size 38mm dia - 24 labels per sheet</td><td><a href='/images/templates/CC668.pdf' target='_blank'>Download 668 Template</a></td></tr>-->
<!--<tr><td>468 - Label Size 35mm dia - 35 labels per sheet</td><td><a href='/images/templates/CC468.pdf' target='_blank'>Download 468 Template</a></td></tr>-->
<!--<tr><td>556 - Label Size 32mm dia - 40 labels per sheet</td><td><a href='/images/templates/CC556.pdf' target='_blank'>Download 556 Template</a></td></tr>-->
<!--<tr><td>508 - Label Size 30mm dia - 48 labels per sheet</td><td><a href='/images/templates/CC508.pdf' target='_blank'>Download 508 Template</a></td></tr>-->
<!--<tr><td>467 - Label Size 25.4mm dia - 70 labels per sheet</td><td><a href='/images/templates/CC467.pdf' target='_blank'>Download 467 Template</a></td></tr>-->
<!--<tr><td>466 - Label Size 20mm dia - 108 labels per sheet</td><td><a href='/images/templates/CC466.pdf' target='_blank'>Download 466 Template</a></td></tr>-->
<!--<tr><td>563 - Label Size 20mm dia - 96 labels per sheet</td><td><a href='/images/templates/CC563.pdf' target='_blank'>Download 563 Template</a></td></tr>-->
<!--<tr><td>669 - Label Size 19mm dia - 96 labels per sheet</td><td><a href='/images/templates/CC669.pdf' target='_blank'>Download 669 Template</a></td></tr>-->
<!--<tr><td>670 - Label Size 18mm dia - 117 labels per sheet</td><td><a href='/images/templates/CC670.pdf' target='_blank'>Download 670 Template</a></td></tr>-->
<!--<tr><td>465 - Label Size 15mm dia - 154 labels per sheet</td><td><a href='/images/templates/CC465.pdf' target='_blank'>Download 465 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="oval">Oval</a></th>-->
<!--</tr>-->
<!--<tr><td>481 - Label Size 280mm x 180mm - 1 label per sheet</td><td><a href='/images/templates/CC481.pdf' target='_blank'>Download 481 Template</a></td></tr>-->
<!--<tr><td>659 - Label Size 280mm x 151mm - 1 label per sheet</td><td><a href='/images/templates/CC659.pdf' target='_blank'>Download 659 Template</a></td></tr>-->
<!--<tr><td>480 - Label Size 200mm x 125mm - 2 labels per sheet</td><td><a href='/images/templates/CC480.pdf' target='_blank'>Download 480 Template</a></td></tr>-->
<!--<tr><td>479 - Label Size 140mm x 90mm - 4 labels per sheet</td><td><a href='/images/templates/CC479.pdf' target='_blank'>Download 479 Template</a></td></tr>-->
<!--<tr><td>660 - Label Size 120mm x 64.8mm - 4 labels per sheet</td><td><a href='/images/templates/CC660.pdf' target='_blank'>Download 660 Template</a></td></tr>-->
<!--<tr><td>478 - Label Size 100mm x 55mm - 10 labels per sheet</td><td><a href='/images/templates/CC478.pdf' target='_blank'>Download 478 Template</a></td></tr>-->
<!--<tr><td>568 - Label Size 98mm x 52mm - 10 labels per sheet</td><td><a href='/images/templates/CC568.pdf' target='_blank'>Download 568 Template</a></td></tr>-->
<!--<tr><td>477 - Label Size 65mm x 35mm - 21 labels per sheet</td><td><a href='/images/templates/CC477.pdf' target='_blank'>Download 477 Template</a></td></tr>-->
<!--<tr><td>583 - Label Size 55mm x 25mm - 8 labels per sheet</td><td><a href='/images/templates/CC583.pdf' target='_blank'>Download 583 Template</a></td></tr>-->
<!--<tr><td>567 - Label Size 50mm x 35mm - 21 labels per sheet</td><td><a href='/images/templates/CC567.pdf' target='_blank'>Download 567 Template</a></td></tr>-->
<!--<tr><td>476 - Label Size 49mm x 35mm - 28 labels per sheet</td><td><a href='/images/templates/CC476.pdf' target='_blank'>Download 476 Template</a></td></tr>-->
<!--<tr><td>554 - Label Size 45mm x 25mm - 40 labels per sheet</td><td><a href='/images/templates/CC554.pdf' target='_blank'>Download 554 Template</a></td></tr>-->
<!--<tr><td>475 - Label Size 38mm x 20mm - 60 labels per sheet</td><td><a href='/images/templates/CC475.pdf' target='_blank'>Download 475 Template</a></td></tr>-->
<!--<tr><td>566 - Label Size 38mm x 20mm - 48 labels per sheet</td><td><a href='/images/templates/CC566.pdf' target='_blank'>Download 566 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="tri">Triangle</a></th>-->
<!--</tr>-->
<!--<tr><td>487 - Label Size 279.4mm x 200mm - 1 label per sheet</td><td><a href='/images/templates/CC487.pdf' target='_blank'>Download 487 Template</a></td></tr>-->
<!--<tr><td>486 - Label Size 140mm x 140mm - 3 labels per sheet</td><td><a href='/images/templates/CC486.pdf' target='_blank'>Download 486 Template</a></td></tr>-->
<!--<tr><td>671 - Label Size 109.5mm x 97.15mm - 4 labels per sheet</td><td><a href='/images/templates/CC671.pdf' target='_blank'>Download 671 Template</a></td></tr>-->
<!--<tr><td>485 - Label Size 90mm x 89mm - 6 labels per sheet</td><td><a href='/images/templates/CC485.pdf' target='_blank'>Download 485 Template</a></td></tr>-->
<!--<tr><td>483 - Label Size 70.7mm x 35.35mm - 14 labels per sheet</td><td><a href='/images/templates/CC483.pdf' target='_blank'>Download 483 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="heart">Heart</a></th>-->
<!--</tr>-->
<!--<tr><td>492 - Label Size 70mm x 70mm - 11 labels per sheet</td><td><a href='/images/templates/CC492.pdf' target='_blank'>Download 492 Template</a></td></tr>-->
<!--<tr><td>493 - Label Size 53mm x 50mm - 20 labels per sheet</td><td><a href='/images/templates/CC493.pdf' target='_blank'>Download 493 Template</a></td></tr>-->
<!--<tr><td>570 - Label Size 45mm x 41mm - 24 labels per sheet</td><td><a href='/images/templates/CC570.pdf' target='_blank'>Download 570 Template</a></td></tr>-->
<!--<tr><td>509 - Label Size 30mm x 28mm - 42 labels per sheet</td><td><a href='/images/templates/CC509.pdf' target='_blank'>Download 509 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="star">Starburst</a></th>-->
<!--</tr>-->
<!--<tr><td>491 - Label Size 260mm x 190mm - 1 label per sheet</td><td><a href='/images/templates/CC491.pdf' target='_blank'>Download 491 Template</a></td></tr>-->
<!--<tr><td>490 - Label Size 150mm x 130mm - 2 labels per sheet</td><td><a href='/images/templates/CC490.pdf' target='_blank'>Download 490 Template</a></td></tr>-->
<!--<tr><td>489 - Label Size 65mm x 60mm - 12 labels per sheet</td><td><a href='/images/templates/CC489.pdf' target='_blank'>Download 489 Template</a></td></tr>-->
<!--<tr><td>933 - Label Size 62.5mm x 46.8mm - 15 labels per sheet</td><td><a href='/images/templates/CC933.pdf' target='_blank'>Download 933 Template</a></td></tr>-->
<!--<tr><td>502 - Label Size 44mm x 44mm - 25 labels per sheet</td><td><a href='/images/templates/CC502.pdf' target='_blank'>Download 502 Template</a></td></tr>-->
<!--<tr><td>571 - Label Size 42mm x 42mm - 18 labels per sheet</td><td><a href='/images/templates/CC571.pdf' target='_blank'>Download 571 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="media">Media</a></th>-->
<!--</tr>-->
<!--<tr><td>494 - Label Size Video Set - 6* labels per sheet</td><td><a href='/images/templates/CC494.pdf' target='_blank'>Download 494 Template</a></td></tr>-->
<!--<tr><td>560 - Label Size 117.5mm dia - 2 labels per sheet</td><td><a href='/images/templates/CC560.pdf' target='_blank'>Download 560 Template</a></td></tr>-->
<!--<tr><td>518 - Label Size 115mm dia - 3 labels per sheet</td><td><a href='/images/templates/CC518.pdf' target='_blank'>Download 518 Template</a></td></tr>-->
<!--<tr><td>530 - Label Size 114.5mm dia - 2 labels per sheet</td><td><a href='/images/templates/CC530.pdf' target='_blank'>Download 530 Template</a></td></tr>-->
<!--<tr><td>948 - Label Size 90mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC948.pdf' target='_blank'>Download 948 Template</a></td></tr>-->
<!--<tr><td>505 - Label Size 78mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC505.pdf' target='_blank'>Download 505 Template</a></td></tr>-->
<!--<tr><td>557 - Label Size 84mm x 59mm - 8 labels per sheet</td><td><a href='/images/templates/CC557.pdf' target='_blank'>Download 557 Template</a></td></tr>-->
<!--<tr><td>506 - Label Size 78mm x 59mm - 8 labels per sheet</td><td><a href='/images/templates/CC506.pdf' target='_blank'>Download 506 Template</a></td></tr>-->
<!--<tr><td>504 - Label Size 118.5mm dia - 2* labels per sheet</td><td><a href='/images/templates/CC504.pdf' target='_blank'>Download 504 Template</a></td></tr>-->
<!--<tr><td>496 - Label Size 116mm dia - 2* labels per sheet</td><td><a href='/images/templates/CC496.pdf' target='_blank'>Download 496 Template</a></td></tr>-->
<!--<tr><td>495 - Label Size 89mm x 42mm - 12 labels per sheet</td><td><a href='/images/templates/CC495.pdf' target='_blank'>Download 495 Template</a></td></tr>-->
<!--<tr><td>537 - Label Size 89.5mm x 42mm - 12 labels per sheet</td><td><a href='/images/templates/CC537.pdf' target='_blank'>Download 537 Template</a></td></tr>-->
<!--<tr><td>937 - Label Size 73mm dia - 6 labels per sheet</td><td><a href='/images/templates/CC937.pdf' target='_blank'>Download 937 Template</a></td></tr>-->
<!--<tr><td>938 - Label Size 40mm dia - 20 labels per sheet</td><td><a href='/images/templates/CC938.pdf' target='_blank'>Download 938 Template</a></td></tr>-->
<!--<tr><td>561 - Label Size 34mm dia - 12 labels per sheet</td><td><a href='/images/templates/CC561.pdf' target='_blank'>Download 561 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="other">Other Shapes</a></th>-->
<!--</tr>-->
<!--<tr><td>942 - Label Size 80mm x 80mm - 6 labels per sheet</td><td><a href='/images/templates/CC942.pdf' target='_blank'>Download 942 Template</a></td></tr>-->
<!--<tr><td>925 - Label Size 70mm x 32mm - 10 labels per sheet</td><td><a href='/images/templates/CC925.pdf' target='_blank'>Download 925 Template</a></td></tr>-->
<!--<tr><td>943 - Label Size 56.9mm x 50mm - 12 labels per sheet</td><td><a href='/images/templates/CC943.pdf' target='_blank'>Download 943 Template</a></td></tr>-->
<!--<tr><td>945 - Label Size 40.7mm x 40.7mm - 24 labels per sheet</td><td><a href='/images/templates/CC945.pdf' target='_blank'>Download 945 Template</a></td></tr>-->
<!--<tr><td>946 - Label Size 28.312mm x 25.536mm - 54 labels per sheet</td><td><a href='/images/templates/CC946.pdf' target='_blank'>Download 946 Template</a></td></tr>-->
<!--<tr><td>939 - Label Size 175mm x 87.5mm - 2 labels per sheet</td><td><a href='/images/templates/CC939.pdf' target='_blank'>Download 939 Template</a></td></tr>-->
<!--<tr><td>959 - Label Size 124.6mm x 94.3mm - 6 labels per sheet</td><td><a href='/images/templates/CC959.pdf' target='_blank'>Download 959 Template</a></td></tr>-->
<!--<tr><td>940 - Label Size 110mm x 60mm - 6 labels per sheet</td><td><a href='/images/templates/CC940.pdf' target='_blank'>Download 940 Template</a></td></tr>-->
<!--<tr><td>941 - Label Size 99.1mm x 38.1mm - 14 labels per sheet</td><td><a href='/images/templates/CC941.pdf' target='_blank'>Download 941 Template</a></td></tr>-->
<!--<tr><td>928 - Label Size 80mm x 50mm - 8 labels per sheet</td><td><a href='/images/templates/CC928.pdf' target='_blank'>Download 928 Template</a></td></tr>-->
<!--<tr><td>503 - Label Size 80mm x 15mm - 30 labels per sheet</td><td><a href='/images/templates/CC503.pdf' target='_blank'>Download 503 Template</a></td></tr>-->
<!--<tr><td>930 - Label Size 61mm x 40mm - 8 labels per sheet</td><td><a href='/images/templates/CC930.pdf' target='_blank'>Download 930 Template</a></td></tr>-->
<!--<tr><td>929 - Label Size 60mm x 44mm - 8 labels per sheet</td><td><a href='/images/templates/CC929.pdf' target='_blank'>Download 929 Template</a></td></tr>-->
<!--<tr><td>931 - Label Size 60mm x 40mm - 12 labels per sheet</td><td><a href='/images/templates/CC931.pdf' target='_blank'>Download 931 Template</a></td></tr>-->
<!--<tr><td>973 - Label Size 55.937mm x 48.967mm - 12 labels per sheet</td><td><a href='/images/templates/CC973.pdf' target='_blank'>Download 973 Template</a></td></tr>-->
<!--<tr><td>923 - Label Size 51mm x 33mm - 12 labels per sheet</td><td><a href='/images/templates/CC923.pdf' target='_blank'>Download 923 Template</a></td></tr>-->
<!--<tr><td>921 - Label Size 50mm x 50mm - 12 labels per sheet</td><td><a href='/images/templates/CC921.pdf' target='_blank'>Download 921 Template</a></td></tr>-->
<!--<tr><td>922 - Label Size 50mm x 50mm - 8 labels per sheet</td><td><a href='/images/templates/CC922.pdf' target='_blank'>Download 922 Template</a></td></tr>-->
<!--<tr><td>651 - Label Size 45mm x 25mm - 44 labels per sheet</td><td><a href='/images/templates/CC651.pdf' target='_blank'>Download 651 Template</a></td></tr>-->
<!--<tr><td>944 - Label Size 42mm x 25mm - 55 labels per sheet</td><td><a href='/images/templates/CC944.pdf' target='_blank'>Download 944 Template</a></td></tr>-->
<!--<tr><td>936 - Label Size Multi - 16 labels per sheet</td><td><a href='/images/templates/CC936.pdf' target='_blank'>Download 936 Template</a></td></tr>-->
<!--<tr><td>932 - Label Size Squares & Circles - 12 labels per sheet</td><td><a href='/images/templates/CC932.pdf' target='_blank'>Download 932 Template</a></td></tr>-->
<!--<tr><td>947 - Label Size Rectangles - 12 labels per sheet</td><td><a href='/images/templates/CC947.pdf' target='_blank'>Download 947 Template</a></td></tr>-->
<!--<tr><td>919 - Label Size Demo Die - 11 labels per sheet</td><td><a href='/images/templates/CC919.pdf' target='_blank'>Download 919 Template</a></td></tr>-->
<!--<tr><td>934 - Label Size 67mm x 27mm - 27 labels per sheet</td><td><a href='/images/templates/CC934.pdf' target='_blank'>Download 934 Template</a></td></tr>-->
<!--<tr><td>589 - Label Size 52.5mm x 32mm - 36 labels per sheet</td><td><a href='/images/templates/CC589.pdf' target='_blank'>Download 589 Template</a></td></tr>-->
<!--<tr><td>935 - Label Size 30mm x 30mm - 48 labels per sheet</td><td><a href='/images/templates/CC935.pdf' target='_blank'>Download 935 Template</a></td></tr>-->
<!--<tr><td>949 - Label Size 239.337mm x 53.793mm - 4 labels per sheet</td><td><a href='/images/templates/CC949.pdf' target='_blank'>Download 949 Template</a></td></tr>-->
<!--<tr><td>499 - Label Size 204mm x 139.6mm - 2 labels per sheet</td><td><a href='/images/templates/CC499.pdf' target='_blank'>Download 499 Template</a></td></tr>-->
<!--<tr><td>569 - Label Size 200mm x 136mm - 2 labels per sheet</td><td><a href='/images/templates/CC569.pdf' target='_blank'>Download 569 Template</a></td></tr>-->
<!--<tr><td>500 - Label Size 195mm x 90mm - 3 labels per sheet</td><td><a href='/images/templates/CC500.pdf' target='_blank'>Download 500 Template</a></td></tr>-->
<!--<tr><td>926 - Label Size 190mm x 25mm - 5 labels per sheet</td><td><a href='/images/templates/CC926.pdf' target='_blank'>Download 926 Template</a></td></tr>-->
<!--<tr><td>950 - Label Size 183mm x 70mm - 3 labels per sheet</td><td><a href='/images/templates/CC950.pdf' target='_blank'>Download 950 Template</a></td></tr>-->
<!--<tr><td>951 - Label Size 177.5mm x 65mm - 4 labels per sheet</td><td><a href='/images/templates/CC951.pdf' target='_blank'>Download 951 Template</a></td></tr>-->
<!--<tr><td>952 - Label Size 160mm x 92mm - 3 labels per sheet</td><td><a href='/images/templates/CC952.pdf' target='_blank'>Download 952 Template</a></td></tr>-->
<!--<tr><td>953 - Label Size 157.87mm x 141.63mm - 2 labels per sheet</td><td><a href='/images/templates/CC953.pdf' target='_blank'>Download 953 Template</a></td></tr>-->
<!--<tr><td>954 - Label Size 156.655mm x 141.184mm - 2 labels per sheet</td><td><a href='/images/templates/CC954.pdf' target='_blank'>Download 954 Template</a></td></tr>-->
<!--<tr><td>955 - Label Size 145mm x 55mm - 4 labels per sheet</td><td><a href='/images/templates/CC955.pdf' target='_blank'>Download 955 Template</a></td></tr>-->
<!--<tr><td>497 - Label Size 140mm x 98mm - 4 labels per sheet</td><td><a href='/images/templates/CC497.pdf' target='_blank'>Download 497 Template</a></td></tr>-->
<!--<tr><td>498 - Label Size 140mm x 98mm - 4 labels per sheet</td><td><a href='/images/templates/CC498.pdf' target='_blank'>Download 498 Template</a></td></tr>-->
<!--<tr><td>956 - Label Size 140.829mm x 64.912mm - 6 labels per sheet</td><td><a href='/images/templates/CC956.pdf' target='_blank'>Download 956 Template</a></td></tr>-->
<!--<tr><td>957 - Label Size 140.304mm x 60.006mm - 6 labels per sheet</td><td><a href='/images/templates/CC957.pdf' target='_blank'>Download 957 Template</a></td></tr>-->
<!--<tr><td>958 - Label Size 138mm x 56mm - 4 labels per sheet</td><td><a href='/images/templates/CC958.pdf' target='_blank'>Download 958 Template</a></td></tr>-->
<!--<tr><td>960 - Label Size 117.08mm x 82.885mm - 4 labels per sheet</td><td><a href='/images/templates/CC960.pdf' target='_blank'>Download 960 Template</a></td></tr>-->
<!--<tr><td>961 - Label Size 102mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates/CC961.pdf' target='_blank'>Download 961 Template</a></td></tr>-->
<!--<tr><td>962 - Label Size 100mm x 57mm - 8 labels per sheet</td><td><a href='/images/templates/CC962.pdf' target='_blank'>Download 962 Template</a></td></tr>-->
<!--<tr><td>587 - Label Size 85mm x 55mm - 8 labels per sheet</td><td><a href='/images/templates/CC587.pdf' target='_blank'>Download 587 Template</a></td></tr>-->
<!--<tr><td>963 - Label Size 82mm x 34mm - 15 labels per sheet</td><td><a href='/images/templates/CC963.pdf' target='_blank'>Download 963 Template</a></td></tr>-->
<!--<tr><td>964 - Label Size 76mm x 18mm - 9 labels per sheet</td><td><a href='/images/templates/CC964.pdf' target='_blank'>Download 964 Template</a></td></tr>-->
<!--<tr><td>965 - Label Size 70mm x 38mm - 12 labels per sheet</td><td><a href='/images/templates/CC965.pdf' target='_blank'>Download 965 Template</a></td></tr>-->
<!--<tr><td>966 - Label Size 70mm x 34mm - 15 labels per sheet</td><td><a href='/images/templates/CC966.pdf' target='_blank'>Download 966 Template</a></td></tr>-->
<!--<tr><td>967 - Label Size 67.5mm x 30mm - 15 labels per sheet</td><td><a href='/images/templates/CC967.pdf' target='_blank'>Download 967 Template</a></td></tr>-->
<!--<tr><td>920 - Label Size 65mm x 38mm - 8 labels per sheet</td><td><a href='/images/templates/CC920.pdf' target='_blank'>Download 920 Template</a></td></tr>-->
<!--<tr><td>927 - Label Size 63mm x 40mm - 8 labels per sheet</td><td><a href='/images/templates/CC927.pdf' target='_blank'>Download 927 Template</a></td></tr>-->
<!--<tr><td>968 - Label Size 62mm x 61.777mm - 12 labels per sheet</td><td><a href='/images/templates/CC968.pdf' target='_blank'>Download 968 Template</a></td></tr>-->
<!--<tr><td>969 - Label Size 60mm x 25mm - 24 labels per sheet</td><td><a href='/images/templates/CC969.pdf' target='_blank'>Download 969 Template</a></td></tr>-->
<!--<tr><td>970 - Label Size 59mm x 53mm - 15 labels per sheet</td><td><a href='/images/templates/CC970.pdf' target='_blank'>Download 970 Template</a></td></tr>-->
<!--<tr><td>971 - Label Size 57mm x 57mm - 12 labels per sheet</td><td><a href='/images/templates/CC971.pdf' target='_blank'>Download 971 Template</a></td></tr>-->
<!--<tr><td>972 - Label Size 56.885mm x 34.68mm - 21 labels per sheet</td><td><a href='/images/templates/CC972.pdf' target='_blank'>Download 972 Template</a></td></tr>-->
<!--<tr><td>974 - Label Size 50mm x 40mm - 20 labels per sheet</td><td><a href='/images/templates/CC974.pdf' target='_blank'>Download 974 Template</a></td></tr>-->
<!--</tbody>-->
<!--</table>-->

<!--<p>&nbsp;</p>-->
<!--<h2>A3/SRA3 Die Templates</h2>-->
<!--<table class="trhover" cellspacing="0" cellpadding="2" border="0">-->
<!--<tbody>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="a3rec">A3 Rectangles/Squares</a></th>-->
<!--</tr>-->
<!--<tr><td>835 - Label Size 400mm x 280mm - 1 label per sheet</td><td><a href='/images/templates-a3/835.pdf' target='_blank'>Download 835 Template</a></td></tr>-->
<!--<tr><td>823 - Label Size 280mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates-a3/823.pdf' target='_blank'>Download 823 Template</a></td></tr>-->
<!--<tr><td>833 - Label Size 200mm x 69mm - 8 labels per sheet</td><td><a href='/images/templates-a3/833.pdf' target='_blank'>Download 833 Template</a></td></tr>-->
<!--<tr><td>827 - Label Size 140mm x 97mm - 8 labels per sheet</td><td><a href='/images/templates-a3/827.pdf' target='_blank'>Download 827 Template</a></td></tr>-->
<!--<tr><td>831 - Label Size 135mm x 55mm - 14 labels per sheet</td><td><a href='/images/templates-a3/831.pdf' target='_blank'>Download 831 Template</a></td></tr>-->
<!--<tr><td>819 - Label Size 130mm x 130mm - 6 labels per sheet</td><td><a href='/images/templates-a3/819.pdf' target='_blank'>Download 819 Template</a></td></tr>-->
<!--<tr><td>821 - Label Size 97mm x 68mm - 16 labels per sheet</td><td><a href='/images/templates-a3/821.pdf' target='_blank'>Download 821 Template</a></td></tr>-->
<!--<tr><td>825 - Label Size 90mm x 55mm - 18 labels per sheet</td><td><a href='/images/templates-a3/825.pdf' target='_blank'>Download 825 Template</a></td></tr>-->
<!--<tr><td>829 - Label Size 90mm x 40mm - 27 labels per sheet</td><td><a href='/images/templates-a3/829.pdf' target='_blank'>Download 829 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="a3other">A3 Other Shapes</a></th>-->
<!--</tr>-->
<!--<tr><td>814 - Label Size 90mm dia - 12 labels per sheet</td><td><a href='/images/templates-a3/814.pdf' target='_blank'>Download 814 Template</a></td></tr>-->
<!--<tr><td>816 - Label Size 53mm dia - 30 labels per sheet</td><td><a href='/images/templates-a3/816.pdf' target='_blank'>Download 816 Template</a></td></tr>-->
<!--<tr><td>817 - Label Size 65mm x 35mm - 40 labels per sheet</td><td><a href='/images/templates-a3/817.pdf' target='_blank'>Download 817 Template</a></td></tr>-->
<!--<tr><td>815 - Label Size 115mm dia - 6 labels per sheet</td><td><a href='/images/templates-a3/815.pdf' target='_blank'>Download 815 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="sra3rec">SRA3 Rectangles/Squares</a></th>-->
<!--</tr>-->
<!--<tr><td>836 - Label Size 400mm x 280mm - 1 label per sheet</td><td><a href='/images/templates-a3/836.pdf' target='_blank'>Download 836 Template</a></td></tr>-->
<!--<tr><td>824 - Label Size 280mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates-a3/824.pdf' target='_blank'>Download 824 Template</a></td></tr>-->
<!--<tr><td>834 - Label Size 200mm x 69mm - 8 labels per sheet</td><td><a href='/images/templates-a3/834.pdf' target='_blank'>Download 834 Template</a></td></tr>-->
<!--<tr><td>828 - Label Size 140mm x 97mm - 8 labels per sheet</td><td><a href='/images/templates-a3/828.pdf' target='_blank'>Download 828 Template</a></td></tr>-->
<!--<tr><td>832 - Label Size 135mm x 55mm - 14 labels per sheet</td><td><a href='/images/templates-a3/832.pdf' target='_blank'>Download 832 Template</a></td></tr>-->
<!--<tr><td>820 - Label Size 130mm x 130mm - 6 labels per sheet</td><td><a href='/images/templates-a3/820.pdf' target='_blank'>Download 820 Template</a></td></tr>-->
<!--<tr><td>822 - Label Size 97mm x 68mm - 16 labels per sheet</td><td><a href='/images/templates-a3/822.pdf' target='_blank'>Download 822 Template</a></td></tr>-->
<!--<tr><td>826 - Label Size 90mm x 55mm - 18 labels per sheet</td><td><a href='/images/templates-a3/826.pdf' target='_blank'>Download 826 Template</a></td></tr>-->
<!--<tr><td>830 - Label Size 90mm x 40mm - 27 labels per sheet</td><td><a href='/images/templates-a3/830.pdf' target='_blank'>Download 830 Template</a></td></tr>-->
<!--<tr>-->
<!--	<td><p> </p></td>-->
<!--</tr>-->
<!--<tr>-->
<!--	<th colspan="2" style="text-align: left;"><a name="sra3other">SRA3 Other Shapes</a></th>-->
<!--</tr>-->
<!--<tr><td>818 - Label Size 65mm x 35mm - 40 labels per sheet</td><td><a href='/images/templates-a3/818.pdf' target='_blank'>Download 818 Template</a></td></tr>-->
<!--</tbody>-->
<!--</table>-->
<!--<p>&nbsp;</p>-->











<title>Download Label Templates</title>

<p><strong>We make the largest range of self-adhesive labels <em>in the world!</em> So it's pretty likely that we'll have what you need!</strong></p>
<p>These templates are to help you set up your labels within graphics software. For help on printing labels through Microsoft Word visit our <a href="index.php?main_page=printlabels">How to print your own labels</a> page.</p>
<p>Jump to section:</p>

<h4>A4 Dies</h4>
<ul>
    <li><a href="index.php?main_page=labeltemplates#rec">Rectangle/Square</a></li>
    <li><a href="index.php?main_page=labeltemplates#cir">Circle</a></li>
    <li><a href="index.php?main_page=labeltemplates#oval">Oval</a></li>
    <li><a href="index.php?main_page=labeltemplates#tri">Triangle</a></li>
    <li><a href="index.php?main_page=labeltemplates#heart">Heart</a></li>
    <li><a href="index.php?main_page=labeltemplates#star">Starburst</a></li>
    <li><a href="index.php?main_page=labeltemplates#media">Media</a></li>
    <li><a href="index.php?main_page=labeltemplates#other">Other Shapes</a></li>
</ul>
<h4>A3/SRA3 Dies</h4>
<ul>
    <li><a href="index.php?main_page=labeltemplates#a3rec">A3 Rectangles/Squares</a></li>
    <li><a href="index.php?main_page=labeltemplates#a3other">A3 Other Shapes</a></li>
    <li><a href="index.php?main_page=labeltemplates#sra3rec">SRA3 Rectangles/Squares</a></li>
    <li><a href="index.php?main_page=labeltemplates#sra3other">SRA3 Other Shapes</a></li>
</ul>
<p>&nbsp;</p>
<h2>A4 Die Templates</h2>
<table class="trhover" cellspacing="0" cellpadding="2" border="0">
<tbody>
<tr>
	<th colspan="2" style="text-align: left;"><a name="rec">Rectangle/Square</a></th>
</tr>
<tr><td>A4 - Label Size 295.275mm x 210mm - 1 label per sheet</td><td><a href="/images/templates/A4.pdf" target='_blank'>Download A4 Template</a></td></tr>
<tr><td>40412 - Label Size 295.2mm x 105mm - 2 labels per sheet</td><td><a href='/images/templates/40412.pdf' target='_blank'>Download 40412 Template</a></td></tr>
<tr><td>40675 - Label Size 295.2mm x 70mm - 3 labels per sheet</td><td><a href="/images/templates/40675.pdf" target='_blank'>Download 40675 Template</a></td></tr>
<tr><td>40402 - Label Size 287mm x 84mm - 2 labels per sheet</td><td><a href="/images/templates/40402.pdf" target='_blank'>Download 40402 Template</a></td></tr>
<tr><td>40436 - Label Size 284mm x 64mm - 3 labels per sheet</td><td><a href="/images/templates/40436.pdf" target='_blank'>Download 40436 Template</a></td></tr>
<tr><td>40450 - Label Size 284mm x 48mm - 4 labels per sheet</td><td><a href="/images/templates/40450.pdf" target='_blank'>Download 40450 Template</a></td></tr>
<tr><td>40407 - Label Size 283mm x 200mm - 1 label per sheet</td><td><a href="/images/templates/40407.pdf" target='_blank'>Download 40407 Template</a></td></tr>
<tr><td>40406 - Label Size 270mm x 30mm - 6 labels per sheet</td><td><a href="/images/templates/40406.pdf" target='_blank'>Download 40406 Template</a></td></tr>
<tr><td>40416 - Label Size 261mm x 38.5mm - 5 labels per sheet</td><td><a href="/images/templates/40416.pdf" target='_blank'>Download 40416 Template</a></td></tr>
<tr><td>40482 - Label Size 220mm x 42mm - 4 labels per sheet</td><td><a href="/images/templates/40482.pdf" target='_blank'>Download 40482 Template</a></td></tr>
<tr><td>40484 - Label Size 220mm x 23mm - 7 labels per sheet</td><td><a href="/images/templates/40484.pdf" target='_blank'>Download 40484 Template</a></td></tr>
<tr><td>40403 - Label Size 210mm x 147.6mm - 2 labels per sheet</td><td><a href="/images/templates/40403.pdf" target='_blank'>Download 40403 Template</a></td></tr>
<tr><td>40520 - Label Size 210mm x 98.4mm - 3 labels per sheet</td><td><a href="/images/templates/40520.pdf" target='_blank'>Download 40520 Template</a></td></tr>
<tr><td>40538 - Label Size 210mm x 73.8mm - 4 labels per sheet</td><td><a href="/images/templates/40538.pdf" target='_blank'>Download 40538 Template</a></td></tr>
<tr><td>40404 - Label Size 210mm x 40mm - 7 labels per sheet</td><td><a href="/images/templates/40404.pdf" target='_blank'>Download 40404 Template</a></td></tr>
<tr><td>40488 - Label Size 210mm x 20mm - 7 labels per sheet</td><td><a href="/images/templates/40488.pdf" target='_blank'>Download 40488 Template</a></td></tr>
<tr><td>40405 - Label Size 210mm x 12mm - 23 labels per sheet</td><td><a href="/images/templates/40405.pdf" target='_blank'>Download 40405 Template</a></td></tr>
<tr><td>40510 - Label Size 205mm x 40mm - 4 labels per sheet</td><td><a href="/images/templates/40510.pdf" target='_blank'>Download 40510 Template</a></td></tr>
<tr><td>40517 - Label Size 203mm x 38mm - 6 labels per sheet</td><td><a href="/images/templates/40517.pdf" target='_blank'>Download 40517 Template</a></td></tr>
<tr><td>40408 - Label Size 200mm x 140mm - 2 labels per sheet</td><td><a href="/images/templates/40408.pdf" target='_blank'>Download 40408 Template</a></td></tr>
<tr><td>40409 - Label Size 200mm x 94mm - 3 labels per sheet</td><td><a href="/images/templates/40409.pdf" target='_blank'>Download 40409 Template</a></td></tr>
<tr><td>40410 - Label Size 200mm x 69mm - 4 labels per sheet</td><td><a href="/images/templates/40410.pdf" target='_blank'>Download 40410 Template</a></td></tr>
<tr><td>40411 - Label Size 200mm x 54mm - 5 labels per sheet</td><td><a href="/images/templates/40411.pdf" target='_blank'>Download 40411 Template</a></td></tr>
<tr><td>40513 - Label Size 200mm x 30mm - 9 labels per sheet</td><td><a href="/images/templates/40513.pdf" target='_blank'>Download 40513 Template</a></td></tr>
<tr><td>40532 - Label Size 199.6mm x 143.5mm - 2 labels per sheet</td><td><a href="/images/templates/40532.pdf" target='_blank'>Download 40532 Template</a></td></tr>
<tr><td>40698 - Label Size 195mm x 75mm - 3 labels per sheet</td><td><a href="/images/templates/40698.pdf" target='_blank'>Download 40698 Template</a></td></tr>
<tr><td>40521 - Label Size 177mm x 46mm - 5 labels per sheet</td><td><a href="/images/templates/40521.pdf" target='_blank'>Download 40521 Template</a></td></tr>
<tr><td>40555 - Label Size 174mm x 63mm - 4 labels per sheet</td><td><a href="/images/templates/40555.pdf" target='_blank'>Download 40555 Template</a></td></tr>
<tr><td>40705 - Label Size 170mm x 90mm - 3 labels per sheet</td><td><a href="/images/templates/40705.pdf" target='_blank'>Download 40705 Template</a></td></tr>
<tr><td>40706 - Label Size 165mm x 85mm - 3 labels per sheet</td><td><a href="/images/templates/40706.pdf" target='_blank'>Download 40706 Template</a></td></tr>
<tr><td>40707 - Label Size 165mm x 53mm - 4 labels per sheet</td><td><a href="/images/templates/40707.pdf" target='_blank'>Download 40707 Template</a></td></tr>
<tr><td>40599 - Label Size 155mm x 40mm - 6 labels per sheet</td><td><a href="/images/templates/40599.pdf" target='_blank'>Download 40599 Template</a></td></tr>
<tr><td>40709 - Label Size 151mm x 43mm - 5 labels per sheet</td><td><a href="/images/templates/40709.pdf" target='_blank'>Download 40709 Template</a></td></tr>
<tr><td>40710 - Label Size 150mm x 90mm - 3 labels per sheet</td><td><a href="/images/templates/40710.pdf" target='_blank'>Download 40710 Template</a></td></tr>
<tr><td>40413 - Label Size 147.6mm x 105mm - 4 labels per sheet</td><td><a href="/images/templates/40413.pdf" target='_blank'>Download 40413 Template</a></td></tr>
<tr><td>40464 - Label Size 145mm x 19mm - 14 labels per sheet</td><td><a href="/images/templates/40464.pdf" target='_blank'>Download 40464 Template</a></td></tr>
<tr><td>40531 - Label Size 145mm x 16.9mm - 16 labels per sheet</td><td><a href="/images/templates/40531.pdf" target='_blank'>Download 40531 Template</a></td></tr>
<tr><td>40640 - Label Size 140mm x 97mm - 4 labels per sheet</td><td><a href="/images/templates/40640.pdf" target='_blank'>Download 40640 Template</a></td></tr>
<tr><td>40602 - Label Size 140mm x 35mm - 10 labels per sheet</td><td><a href="/images/templates/40602.pdf" target='_blank'>Download 40602 Template</a></td></tr>
<tr><td>40523 - Label Size 139mm x 99.1mm - 4 labels per sheet</td><td><a href="/images/templates/40523.pdf" target='_blank'>Download 40523 Template</a></td></tr>
<tr><td>40437 - Label Size 138mm x 64mm - 6 labels per sheet</td><td><a href="/images/templates/40437.pdf" target='_blank'>Download 40437 Template</a></td></tr>
<tr><td>40447 - Label Size 138mm x 50mm - 8 labels per sheet</td><td><a href="/images/templates/40447.pdf" target='_blank'>Download 40447 Template</a></td></tr>
<tr><td>40711 - Label Size 135mm x 80mm - 4 labels per sheet</td><td><a href="/images/templates/40711.pdf" target='_blank'>Download 40711 Template</a></td></tr>
<tr><td>40512 - Label Size 135mm x 55mm - 6 labels per sheet</td><td><a href="/images/templates/40512.pdf" target='_blank'>Download 40512 Template</a></td></tr>
<tr><td>40591 - Label Size 135mm x 45mm - 8 labels per sheet</td><td><a href="/images/templates/40591.pdf" target='_blank'>Download 40591 Template</a></td></tr>
<tr><td>40604 - Label Size 128mm x 44mm - 8 labels per sheet</td><td><a href="/images/templates/40604.pdf" target='_blank'>Download 40604 Template</a></td></tr>
<tr><td>40575 - Label Size 125mm x 80mm - 4 labels per sheet</td><td><a href="/images/templates/40575.pdf" target='_blank'>Download 40575 Template</a></td></tr>
<tr><td>40712 - Label Size 120mm x 38mm - 7 labels per sheet</td><td><a href="/images/templates/40712.pdf" target='_blank'>Download 40712 Template</a></td></tr>
<tr><td>40606 - Label Size 119mm x 55mm - 6 labels per sheet</td><td><a href="/images/templates/40606.pdf" target='_blank'>Download 40606 Template</a></td></tr>
<tr><td>40607 - Label Size 117.5mm x 87mm - 4 labels per sheet</td><td><a href="/images/templates/40607.pdf" target='_blank'>Download 40607 Template</a></td></tr>
<tr><td>40608 - Label Size 112.5mm x 45mm - 8 labels per sheet</td><td><a href="/images/templates/40608.pdf" target='_blank'>Download 40608 Template</a></td></tr>
<tr><td>40609 - Label Size 110mm x 90mm - 4 labels per sheet</td><td><a href="/images/templates/40609.pdf" target='_blank'>Download 40609 Template</a></td></tr>
<tr><td>40501 - Label Size 105mm x 94.5mm - 6 labels per sheet</td><td><a href="/images/templates/40501.pdf" target='_blank'>Download 40501 Template</a></td></tr>
<tr><td>40414 - Label Size 105mm x 73.8mm - 8 labels per sheet</td><td><a href="/images/templates/40414.pdf" target='_blank'>Download 40414 Template</a></td></tr>
<tr><td>40522 - Label Size 105mm x 49.2mm - 12 labels per sheet</td><td><a href="/images/templates/40522.pdf" target='_blank'>Download 40522 Template</a></td></tr>
<tr><td>40714 - Label Size 105mm x 40mm - 8 labels per sheet</td><td><a href="/images/templates/40714.pdf" target='_blank'>Download 40714 Template</a></td></tr>
<tr><td>40415 - Label Size 105mm x 36.9mm - 16 labels per sheet</td><td><a href="/images/templates/40415.pdf" target='_blank'>Download 40415 Template</a></td></tr>
<tr><td>40715 - Label Size 105.25mm x 35mm - 10 labels per sheet</td><td><a href="/images/templates/40715.pdf" target='_blank'>Download 40715 Template</a></td></tr>
<tr><td>40581 - Label Size 105mm x 25.4mm - 22 labels per sheet</td><td><a href="/images/templates/40581.pdf" target='_blank'>Download 40581 Template</a></td></tr>
<tr><td>40588 - Label Size 100mm x 10mm - 24 labels per sheet</td><td><a href="/images/templates/40588.pdf" target='_blank'>Download 40588 Template</a></td></tr>
<tr><td>40524 - Label Size 99.1mm x 93.1mm - 6 labels per sheet</td><td><a href="/images/templates/40524.pdf" target='_blank'>Download 40524 Template</a></td></tr>
<tr><td>40525 - Label Size 99.1mm x 67.7mm - 8 labels per sheet</td><td><a href="/images/templates/40525.pdf" target='_blank'>Download 40525 Template</a></td></tr>
<tr><td>40533 - Label Size 99mm x 57mm - 10 labels per sheet</td><td><a href="/images/templates/40533.pdf" target='_blank'>Download 40533 Template</a></td></tr>
<tr><td>40526 - Label Size 99.1mm x 38.1mm - 14 labels per sheet</td><td><a href="/images/templates/40526.pdf" target='_blank'>Download 40526 Template</a></td></tr>
<tr><td>40527 - Label Size 99.1mm x 34mm - 16 labels per sheet</td><td><a href="/images/templates/40527.pdf" target='_blank'>Download 40527 Template</a></td></tr>
<tr><td>40701 - Label Size 98mm x 25.4mm - 20 labels per sheet</td><td><a href="/images/templates/40701.pdf" target='_blank'>Download 40701 Template</a></td></tr>
<tr><td>40418 - Label Size 97mm x 89mm - 6 labels per sheet</td><td><a href="/images/templates/40418.pdf" target='_blank'>Download 40418 Template</a></td></tr>
<tr><td>40539 - Label Size 97mm x 68mm - 8 labels per sheet</td><td><a href="/images/templates/40539.pdf" target='_blank'>Download 40539 Template</a></td></tr>
<tr><td>40559 - Label Size 97mm x 66mm - 8 labels per sheet</td><td><a href="/images/templates/40559.pdf" target='_blank'>Download 40559 Template</a></td></tr>
<tr><td>40419 - Label Size 97mm x 56.5mm - 10 labels per sheet</td><td><a href="/images/templates/40419.pdf" target='_blank'>Download 40419 Template</a></td></tr>
<tr><td>40540 - Label Size 97mm x 50mm - 10 labels per sheet</td><td><a href="/images/templates/40540.pdf" target='_blank'>Download 40540 Template</a></td></tr>
<tr><td>40420 - Label Size 97mm x 47.5mm - 12 labels per sheet</td><td><a href="/images/templates/40420.pdf" target='_blank'>Download 40420 Template</a></td></tr>
<tr><td>40421 - Label Size 97mm x 40mm - 14 labels per sheet</td><td><a href="/images/templates/40421.pdf" target='_blank'>Download 40421 Template</a></td></tr>
<tr><td>40422 - Label Size 97mm x 34mm - 16 labels per sheet</td><td><a href="/images/templates/40422.pdf" target='_blank'>Download 40422 Template</a></td></tr>
<tr><td>40541 - Label Size 97mm x 26mm - 20 labels per sheet</td><td><a href="/images/templates/40541.pdf" target='_blank'>Download 40541 Template</a></td></tr>
<tr><td>40673 - Label Size 97mm x 20mm - 28 labels per sheet</td><td><a href="/images/templates/40673.pdf" target='_blank'>Download 40673 Template</a></td></tr>
<tr><td>40424 - Label Size 97mm x 15mm - 36 labels per sheet</td><td><a href="/images/templates/40424.pdf" target='_blank'>Download 40424 Template</a></td></tr>
<tr><td>40674 - Label Size 95mm x 93mm - 6 labels per sheet</td><td><a href="/images/templates/40674.pdf" target='_blank'>Download 40674 Template</a></td></tr>
<tr><td>40612 - Label Size 95mm x 65mm - 8 labels per sheet</td><td><a href="/images/templates/40612.pdf" target='_blank'>Download 40612 Template</a></td></tr>
<tr><td>40716 - Label Size 94mm x 49mm - 10 labels per sheet</td><td><a href="/images/templates/40716.pdf" target='_blank'>Download 40716 Template</a></td></tr>
<tr><td>40680 - Label Size 93mm x 64mm - 9 labels per sheet</td><td><a href="/images/templates/40680.pdf" target='_blank'>Download 40680 Template</a></td></tr>
<tr><td>40614 - Label Size 93mm x 36mm - 14 labels per sheet</td><td><a href="/images/templates/40614.pdf" target='_blank'>Download 40614 Template</a></td></tr>
<tr><td>40615 - Label Size 92.5mm x 47mm - 8 labels per sheet</td><td><a href="/images/templates/40615.pdf" target='_blank'>Download 40615 Template</a></td></tr>
<tr><td>40446 - Label Size 90mm x 55mm - 9 labels per sheet</td><td><a href="/images/templates/40446.pdf" target='_blank'>Download 40446 Template</a></td></tr>
<tr><td>40514 - Label Size 90mm x 50mm - 10 labels per sheet</td><td><a href="/images/templates/40514.pdf" target='_blank'>Download 40514 Template</a></td></tr>
<tr><td>40616 - Label Size 90mm x 50mm - 10 labels per sheet</td><td><a href="/images/templates/40616.pdf" target='_blank'>Download 40616 Template</a></td></tr>
<tr><td>40717 - Label Size 90mm x 45mm - 10 labels per sheet</td><td><a href="/images/templates/40717.pdf" target='_blank'>Download 40717 Template</a></td></tr>
<tr><td>40542 - Label Size 90mm x 35mm - 14 labels per sheet</td><td><a href="/images/templates/40542.pdf" target='_blank'>Download 40542 Template</a></td></tr>
<tr><td>40618 - Label Size 89mm x 25mm - 21 labels per sheet</td><td><a href="/images/templates/40618.pdf" target='_blank'>Download 40618 Template</a></td></tr>
<tr><td>40590 - Label Size 88mm x 88mm - 6 labels per sheet</td><td><a href="/images/templates/40590.pdf" target='_blank'>Download 40590 Template</a></td></tr>
<tr><td>40718 - Label Size 88mm x 18mm - 30 labels per sheet</td><td><a href="/images/templates/40718.pdf" target='_blank'>Download 40718 Template</a></td></tr>
<tr><td>40620 - Label Size 87.53mm x 16.6mm - 26 labels per sheet</td><td><a href="/images/templates/40620.pdf" target='_blank'>Download 40620 Template</a></td></tr>
<tr><td>40621 - Label Size 86mm x 52.9mm - 8 labels per sheet</td><td><a href="/images/templates/40621.pdf" target='_blank'>Download 40621 Template</a></td></tr>
<tr><td>40719 - Label Size 85mm x 85mm - 6 labels per sheet</td><td><a href="/images/templates/40719.pdf" target='_blank'>Download 40719 Template</a></td></tr>
<tr><td>40720 - Label Size 85mm x 70mm - 6 labels per sheet</td><td><a href="/images/templates/40720.pdf" target='_blank'>Download 40720 Template</a></td></tr>
<tr><td>40578 - Label Size 84mm x 45mm - 12 labels per sheet</td><td><a href="/images/templates/40578.pdf" target='_blank'>Download 40578 Template</a></td></tr>
<tr><td>40721 - Label Size 83mm x 17mm - 30 labels per sheet</td><td><a href="/images/templates/40721.pdf" target='_blank'>Download 40721 Template</a></td></tr>
<tr><td>40625 - Label Size 82mm x 27mm - 18 labels per sheet</td><td><a href="/images/templates/40625.pdf" target='_blank'>Download 40625 Template</a></td></tr>
<tr><td>40626 - Label Size 81mm x 60mm - 9 labels per sheet</td><td><a href="/images/templates/40626.pdf" target='_blank'>Download 40626 Template</a></td></tr>
<tr><td>40627 - Label Size 81mm x 55.827mm - 8 labels per sheet</td><td><a href="/images/templates/40627.pdf" target='_blank'>Download 40627 Template</a></td></tr>
<tr><td>40628 - Label Size 81mm x 9mm - 45 labels per sheet</td><td><a href="/images/templates/40628.pdf" target='_blank'>Download 40628 Template</a></td></tr>
<tr><td>40574 - Label Size 80mm x 80mm - 6 labels per sheet</td><td><a href="/images/templates/40574.pdf" target='_blank'>Download 40574 Template</a></td></tr>
<tr><td>40577 - Label Size 80mm x 65mm - 8 labels per sheet</td><td><a href="/images/templates/40577.pdf" target='_blank'>Download 40577 Template</a></td></tr>
<tr><td>40629 - Label Size 80.081mm x 49.742mm - 10 labels per sheet</td><td><a href="/images/templates/40629.pdf" target='_blank'>Download 40629 Template</a></td></tr>
<tr><td>40630 - Label Size 80mm x 30mm - 18 labels per sheet</td><td><a href="/images/templates/40630.pdf" target='_blank'>Download 40630 Template</a></td></tr>
<tr><td>40631 - Label Size 80mm x 20mm - 22 labels per sheet</td><td><a href="/images/templates/40631.pdf" target='_blank'>Download 40631 Template</a></td></tr>
<tr><td>40632 - Label Size 80mm x 10mm - 40 labels per sheet</td><td><a href="/images/templates/40632.pdf" target='_blank'>Download 40632 Template</a></td></tr>
<tr><td>40723 - Label Size 78mm x 28mm - 16 labels per sheet</td><td><a href="/images/templates/40723.pdf" target='_blank'>Download 40723 Template</a></td></tr>
<tr><td>40426 - Label Size 77mm x 46.5mm - 12 labels per sheet</td><td><a href="/images/templates/40426.pdf" target='_blank'>Download 40426 Template</a></td></tr>
<tr><td>40703 - Label Size 75mm x 60mm - 8 labels per sheet</td><td><a href="/images/templates/40703.pdf" target='_blank'>Download 40703 Template</a></td></tr>
<tr><td>40543 - Label Size 75mm x 51mm - 10 labels per sheet</td><td><a href="/images/templates/40543.pdf" target='_blank'>Download 40543 Template</a></td></tr>
<tr><td>40634 - Label Size 75mm x 40mm - 12 labels per sheet</td><td><a href="/images/templates/40634.pdf" target='_blank'>Download 40634 Template</a></td></tr>
<tr><td>40545 - Label Size 75mm x 34mm - 15 labels per sheet</td><td><a href="/images/templates/40545.pdf" target='_blank'>Download 40545 Template</a></td></tr>
<tr><td>40635 - Label Size 75mm x 32mm - 15 labels per sheet</td><td><a href="/images/templates/40635.pdf" target='_blank'>Download 40635 Template</a></td></tr>
<tr><td>40550 - Label Size 73mm x 23mm - 24 labels per sheet</td><td><a href="/images/templates/40550.pdf" target='_blank'>Download 40550 Template</a></td></tr>
<tr><td>40534 - Label Size 72mm x 63.5mm - 12 labels per sheet</td><td><a href="/images/templates/40534.pdf" target='_blank'>Download 40534 Template</a></td></tr>
<tr><td>40636 - Label Size 72mm x 31mm - 14 labels per sheet</td><td><a href="/images/templates/40636.pdf" target='_blank'>Download 40636 Template</a></td></tr>
<tr><td>40428 - Label Size 71mm x 70mm - 8 labels per sheet</td><td><a href="/images/templates/40428.pdf" target='_blank'>Download 40428 Template</a></td></tr>
<tr><td>40683 - Label Size 71mm x 63.5mm - 12 labels per sheet</td><td><a href="/images/templates/40683.pdf" target='_blank'>Download 40683 Template</a></td></tr>
<tr><td>40687 - Label Size 71mm x 48mm - 16 labels per sheet</td><td><a href="/images/templates/40687.pdf" target='_blank'>Download 40687 Template</a></td></tr>
<tr><td>40429 - Label Size 70mm x 70mm - 12 labels per sheet</td><td><a href="/images/templates/40429.pdf" target='_blank'>Download 40429 Template</a></td></tr>
<tr><td>40430 - Label Size 70mm x 47mm - 18 labels per sheet</td><td><a href="/images/templates/40430.pdf" target='_blank'>Download 40430 Template</a></td></tr>
<tr><td>40637 - Label Size 70mm x 40mm - 12 labels per sheet</td><td><a href="/images/templates/40637.pdf" target='_blank'>Download 40637 Template</a></td></tr>
<tr><td>40431 - Label Size 70mm x 35mm - 24 labels per sheet</td><td><a href="/images/templates/40431.pdf" target='_blank'>Download 40431 Template</a></td></tr>
<tr><td>40677 - Label Size 70mm x 25.4mm - 33 labels per sheet</td><td><a href="/images/templates/40677.pdf" target='_blank'>Download 40677 Template</a></td></tr>
<tr><td>40678 - Label Size 70mm x 20mm - 42 labels per sheet</td><td><a href="/images/templates/40678.pdf" target='_blank'>Download 40678 Template</a></td></tr>
<tr><td>40638 - Label Size 70mm x 18mm - 24 labels per sheet</td><td><a href="/images/templates/40638.pdf" target='_blank'>Download 40638 Template</a></td></tr>
<tr><td>40679 - Label Size 70mm x 12mm - 69 labels per sheet</td><td><a href="/images/templates/40679.pdf" target='_blank'>Download 40679 Template</a></td></tr>
<tr><td>40439 - Label Size 65mm x 65mm - 12 labels per sheet</td><td><a href="/images/templates/40439.pdf" target='_blank'>Download 40439 Template</a></td></tr>
<tr><td>40682 - Label Size 65mm x 40mm - 18 labels per sheet</td><td><a href="/images/templates/40682.pdf" target='_blank'>Download 40682 Template</a></td></tr>
<tr><td>40639 - Label Size 65mm x 7mm - 40 labels per sheet</td><td><a href="/images/templates/40639.pdf" target='_blank'>Download 40639 Template</a></td></tr>
<tr><td>40435 - Label Size 64mm x 54mm - 15 labels per sheet</td><td><a href="/images/templates/40435.pdf" target='_blank'>Download 40435 Template</a></td></tr>
<tr><td>40536 - Label Size 64mm x 33.9mm - 24 labels per sheet</td><td><a href="/images/templates/40536.pdf" target='_blank'>Download 40536 Template</a></td></tr>
<tr><td>40582 - Label Size 64mm x 25.4mm - 30 labels per sheet</td><td><a href="/images/templates/40582.pdf" target='_blank'>Download 40582 Template</a></td></tr>
<tr><td>40442 - Label Size 63.5mm x 46.5mm - 18 labels per sheet</td><td><a href="/images/templates/40442.pdf" target='_blank'>Download 40442 Template</a></td></tr>
<!--<tr><td>535 - Label Size 63.5mm x 46.6mm - 18 labels per sheet</td><td><a href="/images/templates/535.pdf" target='_blank'>Download 535 Template</a></td></tr>-->
<tr><td>40528 - Label Size 63.5mm x 38.1mm - 21 labels per sheet</td><td><a href="/images/templates/40528.pdf" target='_blank'>Download 40528 Template</a></td></tr>
<tr><td>40684 - Label Size 63.5mm x 34mm - 24 labels per sheet</td><td><a href="/images/templates/40684.pdf" target='_blank'>Download 40684 Template</a></td></tr>
<tr><td>40685 - Label Size 63.5mm x 24mm - 33 labels per sheet</td><td><a href="/images/templates/40685.pdf" target='_blank'>Download 40685 Template</a></td></tr>
<tr><td>40579 - Label Size 63.5mm x 23mm - 36 labels per sheet</td><td><a href="/images/templates/40579.pdf" target='_blank'>Download 40579 Template</a></td></tr>
<tr><td>40552 - Label Size 63mm x 18mm - 40 labels per sheet</td><td><a href="/images/templates/40552.pdf" target='_blank'>Download 40552 Template</a></td></tr>
<tr><td>40445 - Label Size 60mm x 50mm - 15 labels per sheet</td><td><a href="/images/templates/40445.pdf" target='_blank'>Download 40445 Template</a></td></tr>
<tr><td>40573 - Label Size 60mm x 32mm - 24 labels per sheet</td><td><a href="/images/templates/40573.pdf" target='_blank'>Download 40573 Template</a></td></tr>
<!--<tr><td>640 - Label Size 60mm x 32mm - 24 labels per sheet</td><td><a href="/images/templates/640.pdf" target='_blank'>Download 640 Template</a></td></tr>-->
<tr><td>40584 - Label Size 60mm x 20mm - 36 labels per sheet</td><td><a href="/images/templates/40584.pdf" target='_blank'>Download 40584 Template</a></td></tr>
<tr><td>40641 - Label Size 60mm x 11mm - 51 labels per sheet</td><td><a href="/images/templates/40641.pdf" target='_blank'>Download 40641 Template</a></td></tr>
<tr><td>40642 - Label Size 56mm x 20mm - 36 labels per sheet</td><td><a href="/images/templates/40642.pdf" target='_blank'>Download 40642 Template</a></td></tr>
<tr><td>40643 - Label Size 55mm x 40mm - 18 labels per sheet</td><td><a href="/images/templates/40643.pdf" target='_blank'>Download 40643 Template</a></td></tr>
<tr><td>40644 - Label Size 55mm x 10mm - 81 labels per sheet</td><td><a href="/images/templates/40644.pdf" target='_blank'>Download 40644 Template</a></td></tr>
<tr><td>40702 - Label Size 52mm x 42mm - 20 labels per sheet</td><td><a href="/images/templates/40702.pdf" target='_blank'>Download 40702 Template</a></td></tr>
<tr><td>40463 - Label Size 52mm x 16mm - 60 labels per sheet</td><td><a href="/images/templates/40463.pdf" target='_blank'>Download 40463 Template</a></td></tr>
<tr><td>40645 - Label Size 51.5mm x 46mm - 20 labels per sheet</td><td><a href="/images/templates/40645.pdf" target='_blank'>Download 40645 Template</a></td></tr>
<tr><td>40546 - Label Size 51mm x 34mm - 25 labels per sheet</td><td><a href="/images/templates/40546.pdf" target='_blank'>Download 40546 Template</a></td></tr>
<tr><td>40549 - Label Size 51mm x 24mm - 35 labels per sheet</td><td><a href="/images/templates/40549.pdf" target='_blank'>Download 40549 Template</a></td></tr>
<tr><td>40686 - Label Size 50mm x 50mm - 20 labels per sheet</td><td><a href="/images/templates/40686.pdf" target='_blank'>Download 40686 Template</a></td></tr>
<tr><td>40544 - Label Size 50mm x 50mm - 15 labels per sheet</td><td><a href="/images/templates/40544.pdf" target='_blank'>Download 40544 Template</a></td></tr>
<tr><td>40452 - Label Size 48mm x 38mm - 28 labels per sheet</td><td><a href="/images/templates/40452.pdf" target='_blank'>Download 40452 Template</a></td></tr>
<tr><td>40449 - Label Size 48.5mm x 25.4mm - 40 labels per sheet</td><td><a href="/images/templates/40449.pdf" target='_blank'>Download 40449 Template</a></td></tr>
<tr><td>40646 - Label Size 48mm x 23.5mm - 30 labels per sheet</td><td><a href="/images/templates/40646.pdf" target='_blank'>Download 40646 Template</a></td></tr>
<tr><td>40453 - Label Size 48mm x 20mm - 56 labels per sheet</td><td><a href="/images/templates/40453.pdf" target='_blank'>Download 40453 Template</a></td></tr>
<tr><td>40689 - Label Size 48mm x 12mm - 92 labels per sheet</td><td><a href="/images/templates/40689.pdf" target='_blank'>Download 40689 Template</a></td></tr>
<tr><td>40647 - Label Size 47mm x 28.36mm - 36 labels per sheet</td><td><a href="/images/templates/40647.pdf" target='_blank'>Download 40647 Template</a></td></tr>
<tr><td>40558 - Label Size 46mm x 11.1mm - 84 labels per sheet</td><td><a href="/images/templates/40558.pdf" target='_blank'>Download 40558 Template</a></td></tr>
<tr><td>40648 - Label Size 45mm x 45mm - 24 labels per sheet</td><td><a href="/images/templates/40648.pdf" target='_blank'>Download 40648 Template</a></td></tr>
<tr><td>40724 - Label Size 45mm x 31mm - 36 labels per sheet</td><td><a href="/images/templates/40724.pdf" target='_blank'>Download 40724 Template</a></td></tr>
<tr><td>40650 - Label Size 45mm x 25mm - 44 labels per sheet</td><td><a href="/images/templates/40650.pdf" target='_blank'>Download 40650 Template</a></td></tr>
<tr><td>40726 - Label Size 43mm x 21mm - 44 labels per sheet</td><td><a href="/images/templates/40726.pdf" target='_blank'>Download 40726 Template</a></td></tr>
<tr><td>40924 - Label Size 43mm x 10mm - 27 labels per sheet</td><td><a href="/images/templates/40924.pdf" target='_blank'>Download 40924 Template</a></td></tr>
<tr><td>40727 - Label Size 42mm x 18mm - 56 labels per sheet</td><td><a href="/images/templates/40727.pdf" target='_blank'>Download 40727 Template</a></td></tr>
<tr><td>40728 - Label Size 41mm x 25mm - 48 labels per sheet</td><td><a href="/images/templates/40728.pdf" target='_blank'>Download 40728 Template</a></td></tr>
<tr><td>40511 - Label Size 40mm x 15mm - 90 labels per sheet</td><td><a href="/images/templates/40511.pdf" target='_blank'>Download 40511 Template</a></td></tr>
<tr><td>40455 - Label Size 38mm x 38mm - 35 labels per sheet</td><td><a href="/images/templates/40455.pdf" target='_blank'>Download 40455 Template</a></td></tr>
<tr><td>40456 - Label Size 38mm x 25.4mm - 50 labels per sheet</td><td><a href="/images/templates/40456.pdf" target='_blank'>Download 40456 Template</a></td></tr>
<tr><td>40729 - Label Size 38mm x 24mm - 40 labels per sheet</td><td><a href="/images/templates/40729.pdf" target='_blank'>Download 40729 Template</a></td></tr>
<tr><td>40529 - Label Size 38.1mm x 21.2mm - 65 labels per sheet</td><td><a href="/images/templates/40529.pdf" target='_blank'>Download 40529 Template</a></td></tr>
<tr><td>40691 - Label Size 35mm x 30mm - 54 labels per sheet</td><td><a href="/images/templates/40691.pdf" target='_blank'>Download 40691 Template</a></td></tr>
<tr><td>40458 - Label Size 35mm x 6mm - 155 labels per sheet</td><td><a href="/images/templates/40458.pdf" target='_blank'>Download 40458 Template</a></td></tr>
<tr><td>40551 - Label Size 34mm x 21mm - 63 labels per sheet</td><td><a href="/images/templates/40551.pdf" target='_blank'>Download 40551 Template</a></td></tr>
<tr><td>40562 - Label Size 33mm x 33mm - 40 labels per sheet</td><td><a href="/images/templates/40562.pdf" target='_blank'>Download 40562 Template</a></td></tr>
<tr><td>40547 - Label Size 33.5mm x 15mm - 80 labels per sheet</td><td><a href="/images/templates/40547.pdf" target='_blank'>Download 40547 Template</a></td></tr>
<tr><td>40515 - Label Size 32mm x 24mm - 72 labels per sheet</td><td><a href="/images/templates/40515.pdf" target='_blank'>Download 40515 Template</a></td></tr>
<tr><td>40730 - Label Size 32mm x 24mm - 64 labels per sheet</td><td><a href="/images/templates/40730.pdf" target='_blank'>Download 40730 Template</a></td></tr>
<tr><td>40459 - Label Size 30mm x 30mm - 48 labels per sheet</td><td><a href="/images/templates/40459.pdf" target='_blank'>Download 40459 Template</a></td></tr>
<tr><td>40507 - Label Size 30mm x 16mm - 96 labels per sheet</td><td><a href="/images/templates/40507.pdf" target='_blank'>Download 40507 Template</a></td></tr>
<tr><td>40548 - Label Size 30mm x 10mm - 168 labels per sheet</td><td><a href="/images/templates/40548.pdf" target='_blank'>Download 40548 Template</a></td></tr>
<tr><td>40576 - Label Size 25mm x 25mm - 70 labels per sheet</td><td><a href="/images/templates/40576.pdf" target='_blank'>Download 40576 Template</a></td></tr>
<tr><td>40460 - Label Size 25mm x 15mm - 126 labels per sheet</td><td><a href="/images/templates/40460.pdf" target='_blank'>Download 40460 Template</a></td></tr>
<tr><td>40516 - Label Size 25mm x 12mm - 120 labels per sheet</td><td><a href="/images/templates/40516.pdf" target='_blank'>Download 40516 Template</a></td></tr>
<tr><td>40657 - Label Size 25mm x 8mm - 114 labels per sheet</td><td><a href="/images/templates/40657.pdf" target='_blank'>Download 40657 Template</a></td></tr>
<tr><td>40658 - Label Size 24mm x 19mm - 90 labels per sheet</td><td><a href="/images/templates/40658.pdf" target='_blank'>Download 40658 Template</a></td></tr>
<tr><td>40461 - Label Size 20mm x 20mm - 126 labels per sheet</td><td><a href="/images/templates/40461.pdf" target='_blank'>Download 40461 Template</a></td></tr>
<tr><td>40694 - Label Size 20mm x 10mm - 252 labels per sheet</td><td><a href="/images/templates/40694.pdf" target='_blank'>Download 40694 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="cir">Circle</a></th>
</tr>
<tr><td>40474 - Label Size 200mm dia - 1 label per sheet</td><td><a href="/images/templates/40474.pdf" target='_blank'>Download 40474 Template</a></td></tr>
<tr><td>40732 - Label Size 150mm dia - 1 label per sheet</td><td><a href="/images/templates/40732.pdf" target='_blank'>Download 40732 Template</a></td></tr>
<tr><td>40473 - Label Size 140mm dia - 2 labels per sheet</td><td><a href="/images/templates/40473.pdf" target='_blank'>Download 40473 Template</a></td></tr>
<!--<tr><td>472 - Label Size 112mm dia - 3 labels per sheet</td><td><a href="/images/templates/472.pdf" target='_blank'>Download 472 Template</a></td></tr>-->
<tr><td>40565 - Label Size 112mm dia - 3 labels per sheet</td><td><a href="/images/templates/40565.pdf" target='_blank'>Download 40565 Template</a></td></tr>
<tr><td>40592 - Label Size 100mm dia - 4 labels per sheet</td><td><a href="/images/templates/40592.pdf" target='_blank'>Download 40592 Template</a></td></tr>
<tr><td>40471 - Label Size 90mm dia - 6 labels per sheet</td><td><a href="/images/templates/40471.pdf" target='_blank'>Download 40471 Template</a></td></tr>
<tr><td>40734 - Label Size 85mm dia - 6 labels per sheet</td><td><a href="/images/templates/40734.pdf" target='_blank'>Download 40734 Template</a></td></tr>
<tr><td>40704 - Label Size 80mm dia - 6 labels per sheet</td><td><a href="/images/templates/40704.pdf" target='_blank'>Download 40704 Template</a></td></tr>
<tr><td>40663 - Label Size 75mm dia - 6 labels per sheet</td><td><a href="/images/templates/40663.pdf" target='_blank'>Download 40663 Template</a></td></tr>
<tr><td>40594 - Label Size 71mm dia - 6 labels per sheet</td><td><a href="/images/templates/40594.pdf" target='_blank'>Download 40594 Template</a></td></tr>
<tr><td>40470 - Label Size 65mm dia - 12 labels per sheet</td><td><a href="/images/templates/40470.pdf" target='_blank'>Download 40470 Template</a></td></tr>
<tr><td>40735 - Label Size 60mm dia - 12 labels per sheet</td><td><a href="/images/templates/40735.pdf" target='_blank'>Download 40735 Template</a></td></tr>
<tr><td>40665 - Label Size 57mm dia - 12 labels per sheet</td><td><a href="/images/templates/40665.pdf" target='_blank'>Download 40665 Template</a></td></tr>
<tr><td>40572 - Label Size 53mm dia - 15 labels per sheet</td><td><a href="/images/templates/40572.pdf" target='_blank'>Download 40572 Template</a></td></tr>
<tr><td>40469 - Label Size 50mm dia - 20 labels per sheet</td><td><a href="/images/templates/40469.pdf" target='_blank'>Download 40469 Template</a></td></tr>
<tr><td>40564 - Label Size 50mm dia - 15 labels per sheet</td><td><a href="/images/templates/40564.pdf" target='_blank'>Download 40564 Template</a></td></tr>
<tr><td>40553 - Label Size 45mm dia - 24 labels per sheet</td><td><a href="/images/templates/40553.pdf" target='_blank'>Download 40553 Template</a></td></tr>
<tr><td>40666 - Label Size 43mm dia - 24 labels per sheet</td><td><a href="/images/templates/40666.pdf" target='_blank'>Download 40666 Template</a></td></tr>
<tr><td>40595 - Label Size 41mm dia - 24 labels per sheet</td><td><a href="/images/templates/40595.pdf" target='_blank'>Download 40595 Template</a></td></tr>
<tr><td>40736 - Label Size 38mm dia - 30 labels per sheet</td><td><a href="/images/templates/40736.pdf" target='_blank'>Download 40736 Template</a></td></tr>
<tr><td>40737 - Label Size 38mm dia - 24 labels per sheet</td><td><a href="/images/templates/40737.pdf" target='_blank'>Download 40737 Template</a></td></tr>
<tr><td>40468 - Label Size 35mm dia - 35 labels per sheet</td><td><a href="/images/templates/40468.pdf" target='_blank'>Download 40468 Template</a></td></tr>
<tr><td>40556 - Label Size 32mm dia - 40 labels per sheet</td><td><a href="/images/templates/40556.pdf" target='_blank'>Download 40556 Template</a></td></tr>
<tr><td>40508 - Label Size 30mm dia - 48 labels per sheet</td><td><a href="/images/templates/40508.pdf" target='_blank'>Download 40508 Template</a></td></tr>
<tr><td>40467 - Label Size 25.4mm dia - 70 labels per sheet</td><td><a href="/images/templates/40467.pdf" target='_blank'>Download 40467 Template</a></td></tr>
<tr><td>40695 - Label Size 20mm dia - 108 labels per sheet</td><td><a href="/images/templates/40695.pdf" target='_blank'>Download 40695 Template</a></td></tr>
<tr><td>40563 - Label Size 20mm dia - 96 labels per sheet</td><td><a href="/images/templates/40563.pdf" target='_blank'>Download 40563 Template</a></td></tr>
<tr><td>40669 - Label Size 19mm dia - 96 labels per sheet</td><td><a href="/images/templates/40669.pdf" target='_blank'>Download 40669 Template</a></td></tr>
<tr><td>40670 - Label Size 18mm dia - 117 labels per sheet</td><td><a href="/images/templates/40670.pdf" target='_blank'>Download 40670 Template</a></td></tr>
<tr><td>40465 - Label Size 15mm dia - 154 labels per sheet</td><td><a href="/images/templates/40465.pdf" target='_blank'>Download 40465 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="oval">Oval</a></th>
</tr>
<tr><td>40481 - Label Size 280mm x 180mm - 1 label per sheet</td><td><a href="/images/templates/40481.pdf" target='_blank'>Download 40481 Template</a></td></tr>
<tr><td>40659 - Label Size 280mm x 151mm - 1 label per sheet</td><td><a href="/images/templates/40659.pdf" target='_blank'>Download 40659 Template</a></td></tr>
<tr><td>40480 - Label Size 200mm x 125mm - 2 labels per sheet</td><td><a href="/images/templates/40480.pdf" target='_blank'>Download 40480 Template</a></td></tr>
<tr><td>40479 - Label Size 140mm x 90mm - 4 labels per sheet</td><td><a href="/images/templates/40479.pdf" target='_blank'>Download 40479 Template</a></td></tr>
<tr><td>40660 - Label Size 120mm x 64.8mm - 4 labels per sheet</td><td><a href="/images/templates/40660.pdf" target='_blank'>Download 40660 Template</a></td></tr>
<tr><td>40478 - Label Size 100mm x 55mm - 10 labels per sheet</td><td><a href="/images/templates/40478.pdf" target='_blank'>Download 40478 Template</a></td></tr>
<tr><td>40568 - Label Size 98mm x 52mm - 10 labels per sheet</td><td><a href="/images/templates/40568.pdf" target='_blank'>Download 40568 Template</a></td></tr>
<tr><td>40477 - Label Size 65mm x 35mm - 21 labels per sheet</td><td><a href="/images/templates/40477.pdf" target='_blank'>Download 40477 Template</a></td></tr>
<tr><td>40583 - Label Size 55mm x 25mm - 8 labels per sheet</td><td><a href="/images/templates/40583.pdf" target='_blank'>Download 40583 Template</a></td></tr>
<tr><td>40567 - Label Size 50mm x 35mm - 21 labels per sheet</td><td><a href="/images/templates/40567.pdf" target='_blank'>Download 40567 Template</a></td></tr>
<tr><td>40476 - Label Size 49mm x 35mm - 28 labels per sheet</td><td><a href="/images/templates/40476.pdf" target='_blank'>Download 40476 Template</a></td></tr>
<tr><td>40554 - Label Size 45mm x 25mm - 40 labels per sheet</td><td><a href="/images/templates/40554.pdf" target='_blank'>Download 40554 Template</a></td></tr>
<tr><td>40475 - Label Size 38mm x 20mm - 60 labels per sheet</td><td><a href="/images/templates/40475.pdf" target='_blank'>Download 40475 Template</a></td></tr>
<tr><td>40566 - Label Size 38mm x 20mm - 48 labels per sheet</td><td><a href="/images/templates/40566.pdf" target='_blank'>Download 40566 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="tri">Triangle</a></th>
</tr>
<tr><td>40487 - Label Size 279.4mm x 200mm - 1 label per sheet</td><td><a href="/images/templates/40487.pdf" target='_blank'>Download 40487 Template</a></td></tr>
<tr><td>40486 - Label Size 140mm x 140mm - 3 labels per sheet</td><td><a href="/images/templates/40486.pdf" target='_blank'>Download 40486 Template</a></td></tr>
<tr><td>40671 - Label Size 109.5mm x 97.15mm - 4 labels per sheet</td><td><a href="/images/templates/40671.pdf" target='_blank'>Download 40671 Template</a></td></tr>
<tr><td>40485 - Label Size 90mm x 89mm - 6 labels per sheet</td><td><a href="/images/templates/40485.pdf" target='_blank'>Download 40485 Template</a></td></tr>
<tr><td>40483 - Label Size 70.7mm x 35.35mm - 14 labels per sheet</td><td><a href="/images/templates/40483.pdf" target='_blank'>Download 40483 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="heart">Heart</a></th>
</tr>
<tr><td>40492 - Label Size 70mm x 70mm - 11 labels per sheet</td><td><a href="/images/templates/40492.pdf" target='_blank'>Download 40492 Template</a></td></tr>
<tr><td>40493 - Label Size 53mm x 50mm - 20 labels per sheet</td><td><a href="/images/templates/40493.pdf" target='_blank'>Download 40493 Template</a></td></tr>
<tr><td>40570 - Label Size 45mm x 41mm - 24 labels per sheet</td><td><a href="/images/templates/40570.pdf" target='_blank'>Download 40570 Template</a></td></tr>
<tr><td>40509 - Label Size 30mm x 28mm - 42 labels per sheet</td><td><a href="/images/templates/40509.pdf" target='_blank'>Download 40509 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="star">Starburst</a></th>
</tr>
<tr><td>40491 - Label Size 260mm x 190mm - 1 label per sheet</td><td><a href="/images/templates/40491.pdf" target='_blank'>Download 40491 Template</a></td></tr>
<tr><td>40490 - Label Size 150mm x 130mm - 2 labels per sheet</td><td><a href="/images/templates/40490.pdf" target='_blank'>Download 40490 Template</a></td></tr>
<tr><td>40489 - Label Size 65mm x 60mm - 12 labels per sheet</td><td><a href="/images/templates/40489.pdf" target='_blank'>Download 40489 Template</a></td></tr>
<tr><td>40933 - Label Size 62.5mm x 46.8mm - 15 labels per sheet</td><td><a href="/images/templates/40933.pdf" target='_blank'>Download 40933 Template</a></td></tr>
<tr><td>40502 - Label Size 44mm x 44mm - 25 labels per sheet</td><td><a href="/images/templates/40502.pdf" target='_blank'>Download 40502 Template</a></td></tr>
<tr><td>40571 - Label Size 42mm x 42mm - 18 labels per sheet</td><td><a href="/images/templates/40571.pdf" target='_blank'>Download 40571 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="media">Media</a></th>
</tr>
<!--<tr><td>494 - Label Size Video Set - 6* labels per sheet</td><td><a href="/images/templates/494.pdf" target='_blank'>Download 494 Template</a></td></tr>-->
<tr><td>40560 - Label Size 117.5mm dia - 2 labels per sheet</td><td><a href="/images/templates/40560.pdf" target='_blank'>Download 40560 Template</a></td></tr>
<tr><td>40697 - Label Size 115mm dia - 3 labels per sheet</td><td><a href="/images/templates/40697.pdf" target='_blank'>Download 40697 Template</a></td></tr>
<tr><td>40530 - Label Size 114.5mm dia - 2 labels per sheet</td><td><a href="/images/templates/40530.pdf" target='_blank'>Download 40530 Template</a></td></tr>
<tr><td>40948 - Label Size 90mm dia - 6 labels per sheet</td><td><a href="/images/templates/40948.pdf" target='_blank'>Download 40948 Template</a></td></tr>
<tr><td>40505 - Label Size 78mm dia - 6 labels per sheet</td><td><a href="/images/templates/40505.pdf" target='_blank'>Download 40505 Template</a></td></tr>
<tr><td>40557 - Label Size 84mm x 59mm - 8 labels per sheet</td><td><a href="/images/templates/40557.pdf" target='_blank'>Download 40557 Template</a></td></tr>
<tr><td>40506 - Label Size 78mm x 59mm - 8 labels per sheet</td><td><a href="/images/templates/40506.pdf" target='_blank'>Download 40506 Template</a></td></tr>
<tr><td>40504 - Label Size 118.5mm dia - 2* labels per sheet</td><td><a href="/images/templates/40504.pdf" target='_blank'>Download 40504 Template</a></td></tr>
<tr><td>40496 - Label Size 116mm dia - 2* labels per sheet</td><td><a href="/images/templates/40496.pdf" target='_blank'>Download 40496 Template</a></td></tr>
<tr><td>40495 - Label Size 89mm x 42mm - 12 labels per sheet</td><td><a href="/images/templates/40495.pdf" target='_blank'>Download 40495 Template</a></td></tr>
<tr><td>40537 - Label Size 89.5mm x 42mm - 12 labels per sheet</td><td><a href="/images/templates/40537.pdf" target='_blank'>Download 40537 Template</a></td></tr>
<tr><td>40937 - Label Size 73mm dia - 6 labels per sheet</td><td><a href="/images/templates/40937.pdf" target='_blank'>Download 40937 Template</a></td></tr>
<tr><td>40938 - Label Size 40mm dia - 20 labels per sheet</td><td><a href="/images/templates/40938.pdf" target='_blank'>Download 40938 Template</a></td></tr>
<tr><td>40561 - Label Size 34mm dia - 12 labels per sheet</td><td><a href="/images/templates/40561.pdf" target='_blank'>Download 40561 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="other">Other Shapes</a></th>
</tr>
<tr><td>40942 - Label Size 80mm x 80mm - 6 labels per sheet</td><td><a href="/images/templates/40942.pdf" target='_blank'>Download 40942 Template</a></td></tr>
<tr><td>40925 - Label Size 70mm x 32mm - 10 labels per sheet</td><td><a href="/images/templates/40925.pdf" target='_blank'>Download 40925 Template</a></td></tr>
<tr><td>40943 - Label Size 56.9mm x 50mm - 12 labels per sheet</td><td><a href="/images/templates/40943.pdf" target='_blank'>Download 40943 Template</a></td></tr>
<tr><td>40945 - Label Size 40.7mm x 40.7mm - 24 labels per sheet</td><td><a href="/images/templates/40945.pdf" target='_blank'>Download 40945 Template</a></td></tr>
<tr><td>40946 - Label Size 28.312mm x 25.536mm - 54 labels per sheet</td><td><a href="/images/templates/40946.pdf" target='_blank'>Download 40946 Template</a></td></tr>
<tr><td>40939 - Label Size 175mm x 87.5mm - 2 labels per sheet</td><td><a href="/images/templates/40939.pdf" target='_blank'>Download 40939 Template</a></td></tr>
<tr><td>40959 - Label Size 124.6mm x 94.3mm - 6 labels per sheet</td><td><a href="/images/templates/40959.pdf" target='_blank'>Download 40959 Template</a></td></tr>
<tr><td>40940 - Label Size 110mm x 60mm - 6 labels per sheet</td><td><a href="/images/templates/40940.pdf" target='_blank'>Download 40940 Template</a></td></tr>
<tr><td>40941 - Label Size 99.1mm x 38.1mm - 14 labels per sheet</td><td><a href="/images/templates/40941.pdf" target='_blank'>Download 40941 Template</a></td></tr>
<tr><td>40928 - Label Size 80mm x 50mm - 8 labels per sheet</td><td><a href="/images/templates/40928.pdf" target='_blank'>Download 40928 Template</a></td></tr>
<tr><td>40696 - Label Size 80mm x 15mm - 30 labels per sheet</td><td><a href="/images/templates/40696.pdf" target='_blank'>Download 40696 Template</a></td></tr>
<tr><td>40930 - Label Size 61mm x 40mm - 8 labels per sheet</td><td><a href="/images/templates/40930.pdf" target='_blank'>Download 40930 Template</a></td></tr>
<tr><td>40929 - Label Size 60mm x 44mm - 8 labels per sheet</td><td><a href="/images/templates/40929.pdf" target='_blank'>Download 40929 Template</a></td></tr>
<tr><td>40931 - Label Size 60mm x 40mm - 12 labels per sheet</td><td><a href="/images/templates/40931.pdf" target='_blank'>Download 40931 Template</a></td></tr>
<tr><td>40973 - Label Size 55.937mm x 48.967mm - 12 labels per sheet</td><td><a href="/images/templates/40973.pdf" target='_blank'>Download 40973 Template</a></td></tr>
<tr><td>40923 - Label Size 51mm x 33mm - 12 labels per sheet</td><td><a href="/images/templates/40923.pdf" target='_blank'>Download 40923 Template</a></td></tr>
<tr><td>40921 - Label Size 50mm x 50mm - 12 labels per sheet</td><td><a href="/images/templates/40921.pdf" target='_blank'>Download 40921 Template</a></td></tr>
<tr><td>40922 - Label Size 50mm x 50mm - 8 labels per sheet</td><td><a href="/images/templates/40922.pdf" target='_blank'>Download 40922 Template</a></td></tr>
<tr><td>40651 - Label Size 45mm x 25mm - 44 labels per sheet</td><td><a href="/images/templates/40651.pdf" target='_blank'>Download 40651 Template</a></td></tr>
<!--<tr><td>944 - Label Size 42mm x 25mm - 55 labels per sheet</td><td><a href="/images/templates/944.pdf" target='_blank'>Download 944 Template</a></td></tr>-->
<tr><td>40810 - Label Size Multi - 16 labels per sheet</td><td><a href="/images/templates/40810.pdf" target='_blank'>Download 40810 Template</a></td></tr>
<!--<tr><td>932 - Label Size Squares & Circles - 12 labels per sheet</td><td><a href="/images/templates/932.pdf" target='_blank'>Download 932 Template</a></td></tr>-->
<tr><td>40814 - Label Size Rectangles - 12 labels per sheet</td><td><a href="/images/templates/40814.pdf" target='_blank'>Download 40814 Template</a></td></tr>
<tr><td>40919 - Label Size Demo Die - 11 labels per sheet</td><td><a href="/images/templates/40919.pdf" target='_blank'>Download 40919 Template</a></td></tr>
<tr><td>40934 - Label Size 67mm x 27mm - 27 labels per sheet</td><td><a href="/images/templates/40934.pdf" target='_blank'>Download 40934 Template</a></td></tr>
<tr><td>40589 - Label Size 52.5mm x 32mm - 36 labels per sheet</td><td><a href="/images/templates/40589.pdf" target='_blank'>Download 40589 Template</a></td></tr>
<tr><td>40935 - Label Size 30mm x 30mm - 48 labels per sheet</td><td><a href="/images/templates/40935.pdf" target='_blank'>Download 40935 Template</a></td></tr>
<tr><td>40949 - Label Size 239.337mm x 53.793mm - 4 labels per sheet</td><td><a href="/images/templates/40949.pdf" target='_blank'>Download 40949 Template</a></td></tr>
<tr><td>40499 - Label Size 204mm x 139.6mm - 2 labels per sheet</td><td><a href="/images/templates/40499.pdf" target='_blank'>Download 40499 Template</a></td></tr>
<tr><td>40569 - Label Size 200mm x 136mm - 2 labels per sheet</td><td><a href="/images/templates/40569.pdf" target='_blank'>Download 40569 Template</a></td></tr>
<tr><td>40500 - Label Size 195mm x 90mm - 3 labels per sheet</td><td><a href="/images/templates/40500.pdf" target='_blank'>Download 40500 Template</a></td></tr>
<tr><td>40926 - Label Size 190mm x 25mm - 5 labels per sheet</td><td><a href="/images/templates/40926.pdf" target='_blank'>Download 40926 Template</a></td></tr>
<tr><td>40950 - Label Size 183mm x 70mm - 3 labels per sheet</td><td><a href="/images/templates/40950.pdf" target='_blank'>Download 40950 Template</a></td></tr>
<tr><td>40951 - Label Size 177.5mm x 65mm - 4 labels per sheet</td><td><a href="/images/templates/40951.pdf" target='_blank'>Download 40951 Template</a></td></tr>
<tr><td>40952 - Label Size 160mm x 92mm - 3 labels per sheet</td><td><a href="/images/templates/40952.pdf" target='_blank'>Download 40952 Template</a></td></tr>
<tr><td>40953 - Label Size 157.87mm x 141.63mm - 2 labels per sheet</td><td><a href="/images/templates/40953.pdf" target='_blank'>Download 40953 Template</a></td></tr>
<tr><td>40954 - Label Size 156.655mm x 141.184mm - 2 labels per sheet</td><td><a href="/images/templates/40954.pdf" target='_blank'>Download 40954 Template</a></td></tr>
<!--<tr><td>955 - Label Size 145mm x 55mm - 4 labels per sheet</td><td><a href="/images/templates/955.pdf" target='_blank'>Download 955 Template</a></td></tr>-->
<tr><td>40497 - Label Size 140mm x 98mm - 4 labels per sheet</td><td><a href="/images/templates/40497.pdf" target='_blank'>Download 40497 Template</a></td></tr>
<tr><td>40498 - Label Size 140mm x 98mm - 4 labels per sheet</td><td><a href="/images/templates/40498.pdf" target='_blank'>Download 40498 Template</a></td></tr>
<tr><td>40956 - Label Size 140.829mm x 64.912mm - 6 labels per sheet</td><td><a href="/images/templates/40956.pdf" target='_blank'>Download 40956 Template</a></td></tr>
<tr><td>40957 - Label Size 140.304mm x 60.006mm - 6 labels per sheet</td><td><a href="/images/templates/40957.pdf" target='_blank'>Download 40957 Template</a></td></tr>
<tr><td>40958 - Label Size 138mm x 56mm - 4 labels per sheet</td><td><a href="/images/templates/40958.pdf" target='_blank'>Download 40958 Template</a></td></tr>
<tr><td>40960 - Label Size 117.08mm x 82.885mm - 4 labels per sheet</td><td><a href="/images/templates/40960.pdf" target='_blank'>Download 40960 Template</a></td></tr>
<tr><td>40961 - Label Size 102mm x 80mm - 4 labels per sheet</td><td><a href="/images/templates/40961.pdf" target='_blank'>Download 40961 Template</a></td></tr>
<tr><td>40962 - Label Size 100mm x 57mm - 8 labels per sheet</td><td><a href="/images/templates/40962.pdf" target='_blank'>Download 40962 Template</a></td></tr>
<tr><td>40587 - Label Size 85mm x 55mm - 8 labels per sheet</td><td><a href="/images/templates/40587.pdf" target='_blank'>Download 40587 Template</a></td></tr>
<tr><td>40963 - Label Size 82mm x 34mm - 15 labels per sheet</td><td><a href="/images/templates/40963.pdf" target='_blank'>Download 40963 Template</a></td></tr>
<tr><td>40964 - Label Size 76mm x 18mm - 9 labels per sheet</td><td><a href="/images/templates/40964.pdf" target='_blank'>Download 40964 Template</a></td></tr>
<tr><td>40965 - Label Size 70mm x 38mm - 12 labels per sheet</td><td><a href="/images/templates/40965.pdf" target='_blank'>Download 40965 Template</a></td></tr>
<tr><td>40966 - Label Size 70mm x 34mm - 15 labels per sheet</td><td><a href="/images/templates/40966.pdf" target='_blank'>Download 40966 Template</a></td></tr>
<tr><td>40967 - Label Size 67.5mm x 30mm - 15 labels per sheet</td><td><a href="/images/templates/40967.pdf" target='_blank'>Download 40967 Template</a></td></tr>
<tr><td>40920 - Label Size 65mm x 38mm - 8 labels per sheet</td><td><a href="/images/templates/40920.pdf" target='_blank'>Download 40920 Template</a></td></tr>
<tr><td>40927 - Label Size 63mm x 40mm - 8 labels per sheet</td><td><a href="/images/templates/40927.pdf" target='_blank'>Download 40927 Template</a></td></tr>
<tr><td>40968 - Label Size 62mm x 61.777mm - 12 labels per sheet</td><td><a href="/images/templates/40968.pdf" target='_blank'>Download 40968 Template</a></td></tr>
<tr><td>40969 - Label Size 60mm x 25mm - 24 labels per sheet</td><td><a href="/images/templates/40969.pdf" target='_blank'>Download 40969 Template</a></td></tr>
<tr><td>40970 - Label Size 59mm x 53mm - 15 labels per sheet</td><td><a href="/images/templates/40970.pdf" target='_blank'>Download 40970 Template</a></td></tr>
<tr><td>40971 - Label Size 57mm x 57mm - 12 labels per sheet</td><td><a href="/images/templates/40971.pdf" target='_blank'>Download 40971 Template</a></td></tr>
<tr><td>40972 - Label Size 56.885mm x 34.68mm - 21 labels per sheet</td><td><a href="/images/templates/40972.pdf" target='_blank'>Download 40972 Template</a></td></tr>
<tr><td>40974 - Label Size 50mm x 40mm - 20 labels per sheet</td><td><a href="/images/templates/40974.pdf" target='_blank'>Download 40974 Template</a></td></tr>
</tbody>
</table>

<p>&nbsp;</p>
<h2>A3/SRA3 Die Templates</h2>
<table class="trhover" cellspacing="0" cellpadding="2" border="0">
<tbody>
<tr>
	<th colspan="2" style="text-align: left;"><a name="a3rec">A3 Rectangles/Squares</a></th>
</tr>
<tr><td>835 - Label Size 400mm x 280mm - 1 label per sheet</td><td><a href='/images/templates-a3/835.pdf' target='_blank'>Download 835 Template</a></td></tr>
<tr><td>823 - Label Size 280mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates-a3/823.pdf' target='_blank'>Download 823 Template</a></td></tr>
<tr><td>833 - Label Size 200mm x 69mm - 8 labels per sheet</td><td><a href='/images/templates-a3/833.pdf' target='_blank'>Download 833 Template</a></td></tr>
<tr><td>827 - Label Size 140mm x 97mm - 8 labels per sheet</td><td><a href='/images/templates-a3/827.pdf' target='_blank'>Download 827 Template</a></td></tr>
<tr><td>831 - Label Size 135mm x 55mm - 14 labels per sheet</td><td><a href='/images/templates-a3/831.pdf' target='_blank'>Download 831 Template</a></td></tr>
<tr><td>819 - Label Size 130mm x 130mm - 6 labels per sheet</td><td><a href='/images/templates-a3/819.pdf' target='_blank'>Download 819 Template</a></td></tr>
<tr><td>821 - Label Size 97mm x 68mm - 16 labels per sheet</td><td><a href='/images/templates-a3/821.pdf' target='_blank'>Download 821 Template</a></td></tr>
<tr><td>825 - Label Size 90mm x 55mm - 18 labels per sheet</td><td><a href='/images/templates-a3/825.pdf' target='_blank'>Download 825 Template</a></td></tr>
<tr><td>829 - Label Size 90mm x 40mm - 27 labels per sheet</td><td><a href='/images/templates-a3/829.pdf' target='_blank'>Download 829 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="a3other">A3 Other Shapes</a></th>
</tr>
<tr><td>814 - Label Size 90mm dia - 12 labels per sheet</td><td><a href='/images/templates-a3/814.pdf' target='_blank'>Download 814 Template</a></td></tr>
<tr><td>816 - Label Size 53mm dia - 30 labels per sheet</td><td><a href='/images/templates-a3/816.pdf' target='_blank'>Download 816 Template</a></td></tr>
<tr><td>817 - Label Size 65mm x 35mm - 40 labels per sheet</td><td><a href='/images/templates-a3/817.pdf' target='_blank'>Download 817 Template</a></td></tr>
<tr><td>815 - Label Size 115mm dia - 6 labels per sheet</td><td><a href='/images/templates-a3/815.pdf' target='_blank'>Download 815 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="sra3rec">SRA3 Rectangles/Squares</a></th>
</tr>
<tr><td>836 - Label Size 400mm x 280mm - 1 label per sheet</td><td><a href='/images/templates-a3/836.pdf' target='_blank'>Download 836 Template</a></td></tr>
<tr><td>824 - Label Size 280mm x 80mm - 4 labels per sheet</td><td><a href='/images/templates-a3/824.pdf' target='_blank'>Download 824 Template</a></td></tr>
<tr><td>834 - Label Size 200mm x 69mm - 8 labels per sheet</td><td><a href='/images/templates-a3/834.pdf' target='_blank'>Download 834 Template</a></td></tr>
<tr><td>828 - Label Size 140mm x 97mm - 8 labels per sheet</td><td><a href='/images/templates-a3/828.pdf' target='_blank'>Download 828 Template</a></td></tr>
<tr><td>832 - Label Size 135mm x 55mm - 14 labels per sheet</td><td><a href='/images/templates-a3/832.pdf' target='_blank'>Download 832 Template</a></td></tr>
<tr><td>820 - Label Size 130mm x 130mm - 6 labels per sheet</td><td><a href='/images/templates-a3/820.pdf' target='_blank'>Download 820 Template</a></td></tr>
<tr><td>822 - Label Size 97mm x 68mm - 16 labels per sheet</td><td><a href='/images/templates-a3/822.pdf' target='_blank'>Download 822 Template</a></td></tr>
<tr><td>826 - Label Size 90mm x 55mm - 18 labels per sheet</td><td><a href='/images/templates-a3/826.pdf' target='_blank'>Download 826 Template</a></td></tr>
<tr><td>830 - Label Size 90mm x 40mm - 27 labels per sheet</td><td><a href='/images/templates-a3/830.pdf' target='_blank'>Download 830 Template</a></td></tr>
<tr>
	<td><p> </p></td>
</tr>
<tr>
	<th colspan="2" style="text-align: left;"><a name="sra3other">SRA3 Other Shapes</a></th>
</tr>
<tr><td>818 - Label Size 65mm x 35mm - 40 labels per sheet</td><td><a href='/images/templates-a3/818.pdf' target='_blank'>Download 818 Template</a></td></tr>
</tbody>
</table>
<p>&nbsp;</p>